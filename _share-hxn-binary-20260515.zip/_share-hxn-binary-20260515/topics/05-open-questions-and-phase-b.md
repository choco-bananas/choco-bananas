# 05 — 未解明点と Phase B 実装方針

## 解明済み (本パッケージでカバー)

- `.hxn` の復号 (ZipCrypto password `CL34R_com`)
- ZIP メンバー構成、HXN 1.1 / 2.0 の違い
- ポートラベル encoding (Suffix+Base 形式)
- ポートゲイン encoding (`dB = (byte−204) × 0.355`、0dB=`0xCC`)
- パネルキーレコード (type-0x18 Talk / type-0x10 Listen)、147 byte、フィールドマップ
- ターゲットポート encoding (カードスロット構造)

## 未解明・未確定

- **type-0x10 (Listen) レコードの完全なフィールド対応** — type-0x18 と一部 +4 シフトする
  理由が未確定。Talk レコードほど精査していない
- **`+0x3F` の意味** — 全キーレコードで概ね固定 (`0x04` / `0x03`)。パネル種別関連の可能性
- **3RD PARTY キーの `+0x5D`=16** — 物理カードスロットに対応しない特殊ターゲットの特殊値。
  他の特殊ターゲット (system/virtual) の encoding は未調査
- **crosspoint / routing テーブル** の所在と構造 (`Frame0Data.bin` 内のどこか、未解析)
- **matrix-internal section** (Matrix Relay / IFB / AUX / SIP の virtual port table、
  `Frame0Data.bin` の先頭 ~6KB) の詳細構造
- **キーレコードのテンプレート部分** (各レコードで共通の ~120 byte) が表す既定プロパティ群の意味

## Phase B 実装方針

### 推奨: 読み取りは plaintext 優先

`.hxn` から設定を**読む**だけなら、バイナリ (`Frame0Data.bin`) を直接パースするより、

1. **`ProductionMaestro.xml`** (ZIP 内、完全 plaintext XML) を `xml.etree.ElementTree` で
   パース — 全ポートの TalkLabel / ListenLabel / PortType / InputLevel / OutputLevel /
   AbsolutePortNumber 等が取得できる
2. ランタイムのキーアサインは **HCI MSG 380/381** (face↔xpt mapping) で取得 — plaintext で
   ポート番号 + ラベルが直接取れる

の組み合わせが堅実。バイナリ直読みは不要なことが多い。

### バイナリ直接編集について

`Frame0Data.bin` を直接書き換える場合:

- **ラベル変更**: Suffix+Base の 2 文字列を書き換えるだけ。比較的シンプル
- **ポートゲイン変更**: ポートレコード内の 1 byte (`dB→byte` 換算)。シンプル
- **キーアサイン追加**: 147 byte レコードをグループ内のソート位置に挿入。ターゲットは
  (slot, index) = ((port−1)÷16, (port−1)mod16) で計算可能。レコードの GUID は新規生成が必要
- 直接編集後は ZipCrypto で再暗号化して `.hxn` に戻す必要がある

ただし `Frame0Data.bin` には内部オフセットの cascade があり、サイズが変わる挿入を行うと
広範囲に差分が出る (実機 EHX の保存はこれを正しく処理している)。**安易な直接編集より、
EHX configsoft を介すか、HCI のランタイム API を使う方が安全**。

### config を matrix に push する場合

`.hxn` (HXN 2.0) → 実機への push は、HCI 上は SRecord (Motorola S-Record ASCII) 形式の
転送になる (msg 360 + msg 69)。HXN 2.0 → SRecord の変換ロジックは EHX configsoft 内にのみ
存在する。プログラムから push する場合は既存 SRecord の再送か、独自変換器の実装が必要 (難)。

## 関連する発信元の知見 (本パッケージ外)

発信元セッションには、HCI プロトコル本体 (メッセージ仕様、errata) の解析資料が別途ある。
本パッケージは `.hxn` ファイル形式に限定。HCI メッセージ仕様が必要な場合はユーザー経由で
発信元に問い合わせ (別の引継ぎパッケージ `_share-hci-errata-*` が存在する)。
