# 03 — ラベルとゲインの encoding

対象は `Frame0Data.bin` (HXN 2.0、復号後)。詳細は `02-encryption-and-file-format.md`。

## ポートラベル = `[Suffix][Base]` 形式 (Experiment 1)

`Frame0Data.bin` のポートレコード内で、ポートラベルは **サフィックスとベースの 2 文字列**に
分けて格納される:

```
[u32-LE suffix長] [suffix バイト列] [u32-LE base長] [base バイト列] [01]
```

例 (port 0 のラベル `V12RD`):
```
orig:        00 00 00 00            (suffix 長=0、空)
             05 00 00 00 56 31 32 52 44   (base 長=5、"V12RD")
mod1 で →    01 00 00 00 78         (suffix 長=1、"x")
             05 00 00 00 56 31 32 52 44   (base "V12RD")
```

整合性確認 (他ポート):
- `V12RD_2` = suffix `_2` (長2) + base `V12RD` (長5)
- `E-IPA_IVC` = suffix `_IVC` (長4) + base `E-IPA` (長5)
- `E-IPA_AoIP` = suffix `_AoIP` (長5) + base `E-IPA` (長5)

`ProductionMaestro.xml` の `TalkLabel` / `ListenLabel` 属性は、EHX がこの Suffix+Base を
連結した結果。

副次:
- TalkLabel と TalkAlias は自動同期される (ラベル 1 文字変更で size delta が +2 になる)

## ポートゲインの encoding (Experiment 3)

ポートの入出力ゲイン (dB) は `Frame0Data.bin` のポートレコード内に **1 byte** で格納される。

### 換算式 (3 点で確定)

```
dB   = (byte − 204) × 0.355
byte = round(dB ÷ 0.355) + 204
```

| dB | byte | hex |
|---|---|---|
| 0 dB (既定) | 204 | `0xCC` |
| +12 dB | 238 | `0xEE` |
| −45 dB | 77 | `0x4D` |

- **0 dB = `0xCC` (204)** がアンカー
- 1 step = **厳密に 0.355 dB**
- レンジ: byte 0…255 → 約 −72.4 … +18.1 dB
- EHX のドロップダウン "12 dB" は内部的に 12.07 dB に量子化される (34 step × 0.355)

### 格納位置

ポートレコード内 (ラベルの Suffix+Base の前後):
```
... 01 [InputGain:u8] 00 00 00 01 [ラベル GUID 16B] [suffix][base] 00 01 [OutputGain:u8] 00 00 00 01 ...
       ↑ Input Gain (ラベル GUID の手前)                              ↑ Output Gain (ラベル直後)
```
両方とも 1 byte、同一 encoding。

### `ProductionMaestro.xml` にもミラーされる

同じ値が `ProductionMaestro.xml` に `InputLevel="12.07"` のように **十進文字列**でも格納される。
バイナリを触らずゲインを読むだけなら XML から取得するのが簡単。

### 重要な注意: ライブ grid と Port Properties は別系統

- EHX の「Refresh All Crosspoints」(ライブ crosspoint モニタ) で Input Gain を変えても、
  それは**実機マトリクスへのライブパラメータ**で、`.hxn` config のポートレコードには
  書かれない (config 保存しても上記ゲインバイトは変化しない)
- `.hxn` に保存されるゲインは、**設定エディタの Port Properties → Gain Options** で設定したもの
- HCI 開発上の含意: ポートゲインのライブ制御はライブ HCI メッセージ、config 永続化は別、と
  使い分けられている可能性が高い
