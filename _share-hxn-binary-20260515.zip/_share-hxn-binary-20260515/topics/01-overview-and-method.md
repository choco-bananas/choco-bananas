# 01 — 解析の全体像・差分法・ファイル系譜

## 何を解析したか

Clear-Com EHX configsoft が保存する設定ファイル **`.hxn`** の内部構造。HCI 開発で、
matrix の設定 (ポート、パネルキーアサイン、ゲイン等) をプログラムから読み書きするための
一次資料として、実機の EHX が生成する `.hxn` をリバースエンジニアリングした。

`.hxn` は ZipCrypto 暗号化 ZIP (詳細は `02-encryption-and-file-format.md`)。復号すると
`Frame0Data.bin` というバイナリ本体が得られ、その中にポートやパネルキーの定義が入っている。

## 解析手法: ミニマル変更 + Save As + diff

バイナリ構造を直接読むのは困難なため、以下の差分法で encoding を 1 つずつ特定した:

1. EHX configsoft で **設定を 1 箇所だけ** 変更する
2. **`Save As..`** で別名保存する (※`Apply` はしない = 実機 matrix には影響しない、安全)
3. 変更前後の `.hxn` を復号し、`Frame0Data.bin` を byte 単位で diff
4. 差分から、変更した設定がどのバイトに対応するかを特定

EHX の保存出力は (復号後の視点では) 非常に clean で、1 箇所の設定変更が
ほぼ 1 箇所の差分になる (保存タイムスタンプ等のノイズを除けば)。

## ファイル系譜 (実験で生成した `.hxn` 群)

すべて発信元の Desktop に保存。baseline からの累積変更:

| ファイル | 変更内容 | 対応実験 |
|---|---|---|
| `デスクのMedian.hxn` | baseline (元) | — |
| `-mod1.hxn` | ポートラベル `V12RD` → `V12RDx` | Experiment 1 |
| `-mod2.hxn` | + パネルキー Talk アサイン (V12RDx 上段キー2 → E-IPA_AoIP) | Experiment 2 |
| `-mod3.hxn` | + ライブ crosspoint モニタで Input Gain 0→3dB | Experiment 3 (第1回) |
| `-mod4.hxn` | + Port Properties で Input Gain 0→12dB | Experiment 3 (再試行) |
| `-mod5.hxn` | + Port Properties で Input Gain −45dB | Experiment 3 (3点目) |
| `-mod6.hxn` | + 2 個目の Talk アサイン (上段キー5 → E-IPA_SIP1) | Experiment 4 |
| `-mod7.hxn` | + 3 個目の Talk アサイン (上段キー3 → E-IPA_AoIP) | Experiment 5 |
| `-mod8.hxn` | + 新規ポート追加 (slot3 に V-Series 24L) + Listen アサイン | Experiment 6 |

## 各実験で判明したこと (要約)

| 実験 | 成果 | 詳細トピック |
|---|---|---|
| 1 | ラベル = `[Suffix][Base]` 形式 | 03 |
| 2 | キーアサイン追加 = 147 byte レコード挿入 | 04 |
| 3 | ポートゲイン = `dB=(byte−204)×0.355`、0dB=`0xCC` | 03 |
| 4 | 147 byte = type-0x18 パネルキーレコード、先頭 u32 = キーインデックス | 04 |
| 5 | ターゲット = (group, index)、キーレコード フィールドマップ確立 | 04 |
| 6 | ターゲット = カードスロット構造、Talk=type-0x18 / Listen=type-0x10 | 04 |

## 解析ツール (発信元 `work/ehx-gui-mockup/` にある)

本パッケージには含めないが、参考まで:

- `dotnet_strings2.py` — DLL の #US heap 走査で ZipCrypto password を発見
- `decrypt_and_explore.py` — `.hxn` 復号 + 中身 dump
- `diff_level*.py` — ゲイン変更 diff (Experiment 3)
- `diff_assign*.py` / `check_target*.py` / `find_listen.py` — キーレコード diff (Experiment 2/4/5/6)

これらは決め打ちの調査スクリプトで、再利用するより同種の diff を書き直す方が早い。

## 解析の安全性について

- 実験はすべて EHX の **`Save As..` (ファイル保存)** のみ。実機 matrix への `Apply` は行っていない
- したがって解析中に実機 matrix の設定は一切変更されていない
- `.hxn` 復号は読み取りのみ
