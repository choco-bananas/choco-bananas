# 02 — 暗号化とファイル形式

## `.hxn` は ZipCrypto 暗号化 ZIP

EHX configsoft の設定ファイル `.hxn` は、ZipCrypto で暗号化された ZIP アーカイブ。

### password = `CL34R_com`

- leet-speak の "Clear_Com"
- `EclipseClientLibrary.dll` 内に **ハードコード**。Clear-Com 全顧客で同一
- DLL は SmartAssembly で難読化されているが、**#US (User Strings) heap** には平文文字列が
  残る (SmartAssembly はメソッド/クラス名は難読化するが user string literal は触らない)。
  `dnfile` で #US heap を ECMA-335 BlobLength 形式で走査し、候補を ZipCrypto password として
  総当りして発見

### Python での復号

ZipCrypto は標準 `zipfile` が対応:

```python
import zipfile
with zipfile.ZipFile("デスクのMedian.hxn") as z:
    for name in z.namelist():
        data = z.open(name, pwd=b"CL34R_com").read()
```

### 暗号化の意図

ZipCrypto は弱暗号で改ざん検出にも使えない。password はハードコード+全顧客共通。
→ commercial secret の保護目的ではなく、**format versioning marker** か **慣習的レガシー** と推測
(同じ Clear-Com の Arcadia 系製品では config 暗号化なし)。

## HXN format には 2 バージョンある

`.hxn` ZIP 内の `Version.xml` が format を示す:

| | EHX save (`.hxn` ファイル) | HCI wire pull (msg 8 経由) |
|---|---|---|
| HXNFormat | **2.0** | **1.1** |
| CompressionFormat | **ZIP** (deflate) | **BZIP** (bzip2) |
| 本体ファイル | `Frame0Data.bin` | `ObjectGraph.bin` |

本パッケージの解析対象は **HXN 2.0 (EHX save)** の `Frame0Data.bin`。
HCI で matrix から pull した場合は HXN 1.1 が返るので注意 (Version.xml の HXNFormat 属性で
動的判定すること)。

## HXN 2.0 `.hxn` の ZIP メンバー構成

| メンバー | 形式 | 中身 |
|---|---|---|
| `Version.xml` | plaintext XML | format metadata (HXNFormat, EHXVersion 等) |
| `ProjectData.bin` | バイナリ (69-74 byte) | project root metadata (ファイル名・保存日時等) |
| `Frame0Data.bin` | バイナリ (~79 KB) | **設定本体** — ポート・パネルキー・relay 等 |
| `ProductionMaestro.xml` | **完全 plaintext XML** | Configuration / Port 一覧 / Frame metadata |

### `ProductionMaestro.xml` は plaintext で読める (重要)

ポートの talk/listen ラベル、ポート種別、IP、レベル等が構造化 XML で取得できる:

```xml
<ProductionMaestro PMFormat="1.0" ObjectModelFormat="V27" ...>
  <Configurations>
    <Configuration Name="New Configuration" FrameName="H_Median"
                   PrimaryIPAddress="192.168.0.150" MatrixType="5" ...>
      <Ports>
        <Port TalkLabel="V12RD" ListenLabel="" PortType="14"
              InputLevel="0" OutputLevel="0" AbsolutePortNumber="0" PortNumber="0" .../>
        ...
```

→ ポート metadata を読むだけなら、バイナリを触らず `xml.etree.ElementTree` で
`ProductionMaestro.xml` をパースするのが最も簡単。InputLevel 等の dB 値もここに十進で入る。

## `Frame0Data.bin` バイナリ本体の概要

設定の本体。先頭の magic とおおまかなレイアウト:

```
bytes 0-4:   91 00 00 00 01            common magic (HXN 共通)
bytes 5-12:  00 00 00 00 / 08 00 00 00  (zero + u32 length=8)
bytes 13-20: "H_Median"                 matrix 名
bytes 38-41: C0 A8 00 96                 = 192.168.0.150 (matrix IP, big-endian)
...
~0x100 まで:  ヘッダ (保存タイムスタンプ等を含む。保存ごとに変化)
~6 KB まで:   matrix-internal section (Matrix Relay / IFB / AUX / SIP 等の virtual port table)
~6 KB 以降:   ポートレコード / パネルキーレコード等
```

文字列はおおむね `[u32-LE 長さ][UTF-8 バイト列]` の length-prefixed 形式。
GUID は 16 byte。数値は基本 u32 little-endian。

### 保存ごとに変わるノイズ

diff する際の注意。設定変更と無関係に毎回変わるもの:
- ヘッダ内の保存タイムスタンプ (FILETIME、`Frame0Data.bin` の 0x4D / 0x90 付近、`ProjectData.bin` の 0x34 付近)
- `Version.xml` / `ProductionMaestro.xml` の `Created=` タイムスタンプ
- 一部の root GUID

## HXN 1.1 (`ObjectGraph.bin`、HCI wire pull の場合)

HCI で pull した場合の本体 `ObjectGraph.bin` は **.NET BinaryFormatter でラップ**されている:

```
offset 0-16:  BinaryFormatter SerializationHeaderRecord
offset 17-26: ArraySinglePrimitive (record type 0x0F) — Byte 配列ヘッダ
offset 27+:   実ペイロード (HXN 1.1 binary 本体)
```

→ HXN 1.1 を扱う場合は offset 27 から実ペイロードを抽出。本体の magic は HXN 2.0 と同じ
`91 00 00 00 01`。HXN 1.1 はヘッダがより compact (matrix 名や IP を持たない)。
