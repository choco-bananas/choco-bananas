# INDEX (トピック検索表)

タスクで参照すべきファイルだけを Read するため、まずこの表で該当箇所を引く。

## トピック一覧

| トピック | ファイル | 使う場面 |
|---|---|---|
| 解析の全体像・差分法・ファイル系譜 | `topics/01-overview-and-method.md` | 何から読むか迷ったら最初に。解析手法とツールの理解 |
| 暗号化・ファイル形式 | `topics/02-encryption-and-file-format.md` | `.hxn` を復号して開く、ZIP メンバー構成を知る、HXN 1.1/2.0 の違い |
| ラベル・ゲイン encoding | `topics/03-label-and-gain-encoding.md` | ポートラベルやポートゲイン (dB) の読み書き |
| パネルキーレコード | `topics/04-panel-key-records.md` | キーアサイン (Talk/Listen) の構造、ターゲットポートの encoding |
| 未解明点・Phase B 実装方針 | `topics/05-open-questions-and-phase-b.md` | 実装の現実解、何が未確定か |

## タスク別の早見

| やりたいこと | 読むファイル |
|---|---|
| `.hxn` を Python で開いて中身を見たい | 02 |
| ポートラベルの格納形式を知りたい | 03 |
| ポートの入出力ゲイン (dB) を読みたい/書きたい | 03 |
| パネルキーのアサイン先 (どのポートに Talk するか) を読みたい | 04 |
| Talk と Listen の区別がどう保存されるか | 04 |
| config を直接書き換える実装をすべきか判断したい | 05 |
| 解析の信頼度・未確定事項を知りたい | 05 |

## キーファクト早見 (詳細は各トピック)

- `.hxn` = ZipCrypto 暗号化 ZIP。**password = `CL34R_com`** (Clear-Com 全顧客共通のハードコード)
- ZIP メンバー: `Version.xml` / `ProjectData.bin` / `Frame0Data.bin` / `ProductionMaestro.xml`
- `ProductionMaestro.xml` = **完全 plaintext**。ポート一覧・ラベル・レベルが XML で読める
- `Frame0Data.bin` = バイナリ本体。ポートレコード・パネルキーレコードを含む
- ポートゲイン: **`dB = (byte − 204) × 0.355`**、0 dB = `0xCC` (204)
- パネルキーレコード: Talk = `type-0x18`、Listen-only = `type-0x10`、各 147 byte
- ターゲットポート = (カードスロット, カード内ポート位置)、`slot = (port−1)÷16`
