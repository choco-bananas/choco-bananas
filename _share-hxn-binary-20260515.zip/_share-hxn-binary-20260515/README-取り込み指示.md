# EHX .hxn config ファイル バイナリ構造解析 引継ぎパッケージ (2026-05-15、MTC HCI セッションから)

## 受領 agent への指示 (まずこれだけ読む)

**全ファイルを pre-load しないこと**。本パッケージは「必要な時に必要箇所を参照」する knowledge base として構造化されている。読む順序:

1. **タスク開始時に読むのはこの README と `INDEX.md` のみ** (合計 ~150 行)
2. ユーザーから具体的タスク (例:「.hxn のポートゲインを書き換えたい」) が出たら、`INDEX.md` の表から対象トピックファイルを引いて **そのファイルだけ Read** する
3. `topics/*.md` は自己完結している。横断的に全体像が欲しい場合のみ `topics/01-overview-and-method.md` を先に読む
4. **絶対にやらないこと**: 全 `topics/*.md` を一気に Read で読み込む (token 浪費)

## このパッケージの目的

Clear-Com Eclipse HX の設定ソフト **EHX configsoft** が生成する設定ファイル **`.hxn`** の内部バイナリ構造を、実機検証で解明した結果をまとめたもの。HCI 2.0 API 開発において、config ファイルの読み取り・書き換えを行う際の一次資料。

解析は「EHX で 1 箇所だけ変更 → 別名保存 → 復号して diff」という差分法で実施 (Experiment 1〜6)。

## 前提知識 (受領セッションが kb 等を使わない件)

- 本パッケージは **kb / マルチテナント等の仕組みを一切必要としない**。普通の markdown ファイル集として扱える
- 文中に `kb#NNN` という参照が出ることがあるが、それは発信元セッションの管理 ID。実体の知見はすべて本パッケージの `topics/` に取り込み済。受領側で kb を引く必要はない
- 解析スクリプトは発信元の `work/ehx-gui-mockup/` にある (`diff_*.py` / `diff_assign*.py` / `check_target*.py` 等)。本パッケージには含めない (必要なら発信元から別途取得)

## ワークスペース配置の推奨

受領 agent の作業フォルダに展開し、読み取り専用 reference として置く:

```
<workspace_root>/
└── notes/hxn-binary/        ← 推奨
    ├── README-取り込み指示.md
    ├── INDEX.md
    └── topics/
```

## 全ファイル一覧 (詳細は INDEX.md)

```
README-取り込み指示.md           (本ファイル)
INDEX.md                          (トピック検索表)
topics/
  01-overview-and-method.md       解析の全体像・差分法・ファイル系譜・ツール
  02-encryption-and-file-format.md ZipCrypto 復号 (password)・HXN 形式・ZIP メンバー構成
  03-label-and-gain-encoding.md   ラベル形式 (Suffix+Base)・ポートゲイン換算式
  04-panel-key-records.md         パネルキーレコード (type-0x18/0x10)・フィールドマップ・ターゲット encoding
  05-open-questions-and-phase-b.md 未解明点・Phase B 実装方針
```

## バージョンと出所

- スナップショット日: **2026-05-15**
- 出所: Clear-Com Eclipse HX matrix の HCI API 実装プロジェクト (会社 PC 環境)
- 検証機材: Median CSU 192.168.0.150、Card Slot 構成 = slot 1-5 MVX-A16 / slot 6 E-IPA-16-HX
- 検証対象 EHX バージョン: 37.122.1.0、HXN format 2.0 (ZIP)

## 機密区分

- 本パッケージは **MTC 業務機密** (Clear-Com proprietary な内部 format 情報、検証機材構成を含む)
- **外部送信禁止**。社外への共有・転載をしないこと
- 自社業務上、ローカルワークスペースに保管・参照するのは可

## 不明点・矛盾を見つけた場合

- 受領側で実機検証して新発見があった場合は、自セッションのローカル notes に記録し **本パッケージにはマージしない** (発信元のバージョン管理を尊重)
- 発信元と統合更新したい場合はユーザー経由で連絡
- 判断つかなければ **ユーザーに照会**
