# Call Signal の HCI 表現

依存: `topics/state-byte-bitmap.md`、`messages/MSG-318-319-321-key-events.md`。

## 結論

EHX の **Call Signal 機能** (panel → 相手に「呼び出し」シグナルを送る) は **HCI 固有の event を持たない**。
EHX 側が **同時押 / 長押のパターンを検出して内部 (audio + signal) を起動**する。

## 機種別トリガと HCI 上の挙動

### V12PD (Push)

- **トリガ動作**: face の **VolUp + VolDn 同時押** (~50ms 以内)
- **HCI 上の emit**:
  - `K=base+2` と `K=base+3` が **~50ms 以内に連続 PRESS** (state=0x01 1 event ずつ)
  - **RELEASE 配信なし** (Call Signal trigger 検出後は release を抑止)
- 一致しないタイミング (>50ms) の場合は単なる Volume tick として扱われる

### V12RD (Rotary)

- **トリガ動作**: face の **rotary push 長押** (slot 1 = Listen を長押し)
- **HCI 上の emit**: `K=base+1` の **標準 LongPush シーケンス**:
  ```
  0x01 (press) → 0x07 (long threshold @ ~250ms) → 0x04 (long release) → 0x00 (idle)
  ```
  特別な marker は出ない。Call Signal action と通常 LongPush の区別は HCI レベルではできない。

### V12LD (Lever) — 推測

検証は明示的に行われていない。Lever は Talk/Listen lever (slot 0/1) で長押し検出可能。Call Signal binding が EHX 側にあるかは EHX 設定に依存。

## Client 側で Call Signal を区別したい場合

matrix 任せでなく、**入力パターンを HCI イベント列から検出** する必要がある:

### V12PD パターン検出 (擬似コード)

```python
last_pressed = {}  # key_id → timestamp
def on_key_event(ev):
    if ev.state == 0x01 and ev.slot in (KEY_SLOT_VOLUP, KEY_SLOT_VOLDN):
        partner_slot = KEY_SLOT_VOLDN if ev.slot == KEY_SLOT_VOLUP else KEY_SLOT_VOLUP
        partner_key = key_of(ev.panel, ev.region, ev.local_face, partner_slot)
        if partner_key in last_pressed:
            dt_ms = (ev.ts - last_pressed[partner_key]) * 1000
            if 0 <= dt_ms <= 50:
                fire_call_signal()
                last_pressed.clear()
                return
        last_pressed[(ev.panel, ev.region, ev.page, ev.key)] = ev.ts
```

### V12RD パターン検出

`messages/MSG-318-319-321-key-events.md` の long-push 系 sequence (`0x01 → 0x07 → 0x04`) で slot=1 (Listen / Rotary push) を見る。

## 重要: bit 3 とは無関係 (2026-05-14 確認)

過去には bit 3 (0x08/0x09) が「他キー同時アクション中の press marker」かもしれないと推測されていたが、**verify_bit3.py で V12PD Call Signal pattern (×3 trials) を含む全パターンで bit 3 = 0**。
詳細: `topics/state-byte-bitmap.md` §5 / `raw/kb-344-bit3-erratum.md`。

## MSG 318 subscription 必須

Call Signal HCI event は **MSG 318 Auto Updates subscribe 中のみ届く**。
3RDPARTY 表示 (MSG 315) には現れない。
