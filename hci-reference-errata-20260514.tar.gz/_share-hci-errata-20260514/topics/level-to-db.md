# Level ↔ dB 変換 (MSG 38 / 39 / 40 / 150 / 151 共通)

HCI Reference §4.18 Appendix C で定義。実機 self-talk = `0xCC` (= 204) で **+0.00 dB** を 2026-05-12 検証で確認。

## 定数

```python
LEVEL_MAX   = 255
LEVEL_0DB   = 204    # = 0xCC
LEVEL_MUTE  = 0
DB_PER_TICK = 0.355  # dB per 1 level tick
```

## 線形換算

```python
# level → dB
db = (level - LEVEL_0DB) * DB_PER_TICK  if level > 0 else -inf

# dB → level
level = round(LEVEL_0DB + db / DB_PER_TICK)
level = max(0, min(255, level))  # clip to [0, 255]
```

## 実機検証 (2026-05-12、kb#341 §G)

| 送信 level | 計算結果 dB | matrix reply | 一致 |
|---|---|---|---|
| 0xCC = 204 | (204-204)*0.355 = +0.000 dB | level=204 (+0.00 dB) | ✓ |
| 0xD5 = 213 | (213-204)*0.355 = +3.195 dB | level=213 (+3.19 dB) | ✓ |
| 0x00 = 0   | (0-204)*0.355 = -72.4 dB (但し MUTE 扱い) | level=0 (MUTE) | ✓ |

## 用法

- 1 tick ≒ **0.355 dB**
- 9 tick ≒ **3.2 dB** (rotary_volume_ctrl.py のデフォルト step)
- level=0 は **soft MUTE** — entry は残る、計算上 -∞ dB 扱いだが reply にも level=0 で現れる
- 上限 255 は **+18.105 dB** ((255-204)*0.355)

## どの MSG で使うか

- MSG 38: Set XPT Level — payload に level u8
- MSG 39/40: Request/Reply XPT Level — reply に (src, level) tuple list
- MSG 150/151: Request/Reply Xpt And Level — reply の entry に level u16 (実質 u8 範囲)
