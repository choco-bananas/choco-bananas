# Connection and Multi-Listener Ports

## ネットワーク

- **CSU IP**: `192.168.0.150`
- **HCI 制御 port**: `52001/tcp` / `52002/tcp` / `52003/tcp` (多重 listener)
- Subnet / VLAN は環境による

## ⚠ Multi-listener (kb#341 §H)

Median CSU は **複数 HCI port listener を独立に開放** している (52001, 52002, 52003 同時開放を 2026-05-13 確認)。

### Stale TCP の問題

前 session の TCP が stale 状態 (TCP keepalive timeout 未到達) で残ると、**低番号 port (52001) は新規接続を拒否する**。

### 対処: Port fallback

Client 実装で複数 port を順次試行:

```python
for port in (52001, 52002, 52003):
    try:
        sock = connect(host, port)
        return sock
    except (ConnectionRefusedError, OSError):
        continue
raise ConnectionError("all ports failed")
```

`work/ehx-gui-mockup/hci_client.py` の `_connect_worker` 実装参照。

### 解放

- Black reset でクリアされる
- 自然タイムアウト (~数分) でも解放される模様

## TCP 接続後の流れ

1. TCP open
2. matrix が **MSG 1 (Broadcast System Message) を broadcast** (TCP error log + connected log)
3. **Reply CPU Status は来ない** (kb#337 #3、manual §2 prose は誤り)
4. host が任意の request を送ると、対応する reply が来始める
5. ~1秒間隔で MSG 363 heartbeat が来る (`messages/MSG-363-heartbeat.md`)

## 認証

- 現状 open? (要確認)
- 実値は記載しない、所在のみ参照

## 接続テスト (PowerShell)

```powershell
$matrixIp = '192.168.0.150'
$ctrlPort = 52001
Test-NetConnection $matrixIp -Port $ctrlPort
```

## 運用ルール

- 接続可能時間帯: **平日 9:00〜18:00 業務時間内**
- 接続トリガ: ユーザー指示後のみ。エージェントは独断接続しない
- Write 系 API (構成変更、xpt routing、認証情報) は **ユーザー確認後** のみ実行
- 実機検証は **会社 PC のみ**
- 接続セッション数 / 認証ロック仕様: 要確認

## 強制 close

`messages/MSG-001-broadcast-system.md` 参照 (kb#337 #19): `SO_LINGER l_onoff=1, l_linger=0` で TCP RST。
