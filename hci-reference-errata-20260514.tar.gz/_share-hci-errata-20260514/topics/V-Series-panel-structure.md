# V-Series Panel 構造 (Region / Face / Key# / Slot mapping)

参照: EclipseHX Logic UserGuide §Ch4 Appendix C "Key Numbering on Panels" (p136-141)。

## 基本構造

```
Panel  →  Region (2x3=6 face、例外 2x2=4 face)  →  Face  →  Key (4 個)
```

| レベル | 単位 | 番号付け |
|---|---|---|
| Panel | 1 物理パネル | HCI port 番号で識別 |
| **Region** | 通常 **2行×3列=6 face**、例外 **2行×2列=4 face** | **下段→上段、左→右** で 1-origin |
| Face | 物理キー面 (label + button 群) | local_face = local_r * 3 + local_c (canonical 2×3 index、0..5) |
| **Key** | 1 つの key# (HCI) | **全 V-Series 機種で 4 keys/face** (stride=4) |

## Panel 種別ごとの region 配置

| Model | face grid | tile col widths | Region 配置 |
|---|---|---|---|
| **V12LD/PD/RD** (1U) | 2×6 | [3, 3] | R1 (left 2×3), R2 (right 2×3) |
| **V24LD/PD/RD** (2U) | 4×6 | [3, 3] | bottom: R1, R2 / top: R3, R4 (各 2×3) |
| **V32LD** (2U 32-Key) | 4×8 | [3, 3, 2] | bottom: R1, R2 (2×3), **R3 (2×2)** / top: R4, R5 (2×3), **R6 (2×2)** |
| **V Desk** (V12L/P/RDD) | 4×3 | [3] | bottom: R1, top: R2 (各 2×3) |
| **V12LDE/PDE/RDE** (1U Exp) | 2×6 | [3, 3] | R1, R2 (各 2×3) |
| **V16LDE** (1U Exp 16-key) | 2×8 | [3, 3, 2] | R1, R2 (2×3), **R3 (2×2)** |

## Key# 計算式 (全 V-Series 共通、stride=4)

```
key_base(local_r, local_c) = local_r * 12 + local_c * 4
                           = local_face * 4   (canonical local_face = local_r*3 + local_c)

talk_key       = key_base + 0   # KEY_SLOT_TALK
listen_key     = key_base + 1   # KEY_SLOT_LISTEN
volup_key      = key_base + 2   # KEY_SLOT_VOLUP
voldn_key      = key_base + 3   # KEY_SLOT_VOLDN
```

## 2×2 region (V16LDE / V32LD の R3/R6)

canonical 2×3 layout の **最右列 (local_c=2) を物理欠落**:

```
local_face 0 (K base 0)    local_face 1 (K base 4)    [local_face 2 absent]
local_face 3 (K base 12)   local_face 4 (K base 16)   [local_face 5 absent]
```

## Slot 意味 × Panel 種別 (実機検証済、kb#341 §D)

各 face 内の 4 key slot は **意味が全 panel 種別で共通**、物理実装のみ異なる:

| Slot | 意味 | Rotary (V12RD) | Lever (V12LD) | Push (V12PD) |
|---|---|---|---|---|
| +0 | **Talk** | **Talk button** (rotary 横の小型物理ボタン) | スイッチ | **BigButton** |
| +1 | **Listen** | **Rotary push** (knob 押し込み) | スイッチ | **HCI 未 emit** (MSG 315 proxy entry も無し) |
| +2 | **VolUp** | Rotary CW 回転 | ボタン | ボタン |
| +3 | **VolDn** | Rotary CCW 回転 | ボタン | ボタン |

### V12RD = 2 物理入力構造 (kb#341 §B)

長らく単一 knob と誤認していたが、実機 V12RD (VI-PNL-12R / VI-PNLB-12R) は **rotary knob + 別の小型 Talk button** の 2 入力構成。

### V12PD slot 1 (Listen) 不在

V12PD は BigButton で Talk + Listen を兼ねるため slot 1 は HCI に届かない。MSG 315 proxy entries も Lever/Rotary の半数 (5 vs 10/12)。

### Rotary slot 2/3 vs Lever/Push slot 2/3 (状態 byte の違い)

- Rotary: 回転 tick で state=0x01 の連続 stream
- Lever/Push: 物理ボタン、state=0x01 1 event のみ (release 配信なし、`topics/state-byte-bitmap.md` §3 参照)

## V-Series Region 番号付けは bottom-up

V24RD (2U) 例: **下段 = R1, R2、上段 = R3, R4**。1 行パネル (1U) では only-row のため影響なし。

## panel_type code (実機マップ)

| code | name |
|---|---|
| 0x8010 | V-Series 1U Lever (V12LD、VI-PNLB-12L) |
| 0x8011 | V-Series 1U Push (V12PD) |
| 0x8016 | V-Series 1U Rotary (V12RD、VI-PNL-12R、VI-PNLB-12R) |

詳細 catalog は MSG 184 詳細 (`messages/MSG-183-184-port-info.md`)。

## Slot ↔ Port mapping (kb#341 関連)

```
HCI slot N  ⇔  configsoft slot (N-1)
HCI slot 2  →  HCI ports 0..15    (= configsoft slot 1, ports 1..16)
HCI slot 7  →  HCI ports 80..95   (= configsoft slot 6, ports 81..96)

port = (slot - 2) * 16 + offset    # HCI slot 1-based, port 0-based
探索範囲: slot 2..20
```

## 実機 V12RD_2 (port 1, 2×6) 検証 (2026-05-11、validation 例)

| EHX 位置 | grid(r,c) | (region, local_face) | 期待 key# | 実観測 (MSG 315) |
|---|---|---|---|---|
| R1C1 | (0,0) | (1, 0) | 0..3 | rgn1 K=0,1 ✓ |
| R1C2 | (0,1) | (1, 1) | 4..7 | rgn1 K=4,5 ✓ |
| R1C5 | (0,4) | (2, 1) | 4..7 | rgn2 K=4,5 ✓ |
| R2C2 | (1,1) | (1, 4) | 16..19 | rgn1 K=16,17 ✓ |
| R2C5 | (1,4) | (2, 4) | 16..19 | rgn2 K=16,17 ✓ |
