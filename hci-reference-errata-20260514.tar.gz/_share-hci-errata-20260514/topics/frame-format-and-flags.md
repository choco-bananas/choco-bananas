# Frame Format and FLAGS

## 標準フレーム

```
[START 0x5A0F][SIZE u16][MSG_ID u16][FLAGS u8]
[MAGIC 0xABBACEDE u32][SCHEMA u8 = 0x01]
[payload bytes...]
[END 0x2E8D]
```

- SIZE = **complete transport packet bytes (start から end まで含む)**、kb#337 #18
- MSG_ID は big-endian u16
- header 部の **固定 8 bytes** = msg_id(2) + flags(1) + magic(4) + schema(1)、`build_packet()` で構築 (kb#337 #6)

## MAGIC NUMBER (kb#337 #4)

§3.1 マニュアルは MAGIC を文書化していないが、**実装は 0xABBACEDE を必須**。matrix 側 parser が `params[2] == 0xABBACEDE` で reject 判定 (HCITrainingDemo より)。

例外: MSG 1 (Broadcast System Message) は MAGIC 無し (`messages/MSG-001-broadcast-system.md`)。

## FLAGS byte の意味

### Host → CSU (送信時)

**`0x08` 固定**。

### CSU → Host (受信時、kb#337 #17)

| 値 | 意味 |
|---|---|
| `0x34` | 通常 reply (MAGIC あり, schema=0x01) |
| `0x30` | Broadcast System Message (msg 1, MAGIC 無し) |
| `0x10` | heartbeat (msg 363, 1 Hz, MAGIC あり, schema=0x02) または status change msg (msg 344 / 361 等) |
| `0x00` | empty replies (msg 313 silent reject 等、msg id 300+ family) |

bit 0x04 in 0x34 vs 0x30 → "standard reply payload" を示すマーカー (推測)。

### MultiPacket flags (MSG 184 等、kb#337 #34)

- 最初 packet: flags bit 4 (E=more) set (例: 0x11)
- 続行 packet: E=1 (例: 0x01)
- 最終 packet: S=0 + E=0 (例: 0x00)

flags' E bit (0x10) が clear になるまで drain。

## ⚠ kb#337 #28: N=1 always は嘘 (msg id 300+ family)

§4.2 で CSU は N=1 を always set すると書くが、新族 (msg 313 / 317 / 319 等) は **flag=0x00** で返る。flag bit pattern で server reply 判定するな → **msg_id + magic** で判定する。

## Ping (kb#337 #7、`messages/MSG-001-broadcast-system.md` 関連)

### 公式マニュアル §3.1.3 の例 (誤り)

```
5A 0F 00 10 00 00 2E 8D   (8 bytes)
```

→ matrix が err 255 で reject、msg 1 broadcast で error log を返す。

### 実機で動く正しい ping (60ms RTT で echo)

```
5A 0F 00 0A 00 00 00 00 2E 8D   (10 bytes、length=0x000A=10)
```

実装: `hci_verifier.protocol.VERIFIED_PING_BYTES` / `build_ping()`.

## TCP close (kb#337 #19)

`SO_LINGER {l_onoff=1, l_linger=0}` で **TCP RST** を発生させる。graceful flush ではない。`HciTransport.close(force_rst=True)` (default)。

## Length field の正しい記述 (kb#337 #18)

通常運用では SIZE = **total packet bytes including start/end**。これは正しい。`§3.1.3 ping example` で長さが矛盾するのは ping 例自体の文書誤り (上記参照)。
