# State Byte Bitmap (MSG 321 の state byte 解読)

依存: `messages/MSG-318-319-321-key-events.md`

## 結論サマリ (2026-05-14 確定版)

MSG 321 の state byte は **bitmap**。1 物理押下で複数 state event が連続発火する。

| state | bits | 意味 |
|---|---|---|
| `0x00` | — | idle / clean (debouncing 完了) |
| `0x01` | bit 0 | 物理スイッチ **down** (押下開始) |
| `0x02` | bit 1 | **Push** event (短押し release、action fired) |
| `0x03` | bit 0+1 | down + Push 同時 — stale 0x07 復帰の最初の release tick |
| `0x04` | bit 2 | **LongPush** event (長押し release、long action fired) |
| `0x07` | bit 0+1+2 | **LongPush 閾値到達** (~200-280ms hold 後)、まだ down |
| `0x08` | bit 3 | **再現せず — 不明** (2026-05-14 verify_bit3.py 系統検証で観測不可、旧記述は erratum) |
| `0x09` | bit 0+3 | **再現せず — 不明** (同上) |

## 典型遷移

| 操作 | sequence |
|---|---|
| 短押し (Talk/Listen) | `0x01 → 0x02 → 0x00` |
| 長押し (Talk/Listen) | `0x01 → 0x07 → 0x04 → 0x00` |
| VolUp/VolDn (Lever/Push) | `0x01` 1 event のみ (release 配信なし) |
| stale 0x07 復帰 | `prev=0x07 → 0x03 → 0x04 → 0x00` |
| Rotary 回転 | slot 2/3 で `0x01` の連続 stream |

## 重要含意

### 1. HCI 層で Push / LongPush を区別済み

client 側で make→break 経過時間を計測する必要なし。**`state & 0x04` で LongPush 判定**。EHX の "Push" / "Long Push" function key 設定と直接対応。

### 2. Long-push 閾値 ~200-280ms (新発見、kb#344)

EHX UI のデフォルト 500-800ms より大幅に短い:

| Panel | Key | 計測 long-push 到達 |
|---|---|---|
| Rotary K=0 Talk button | 218 / 330 ms (cycle 1/2) |
| Rotary K=1 Rotary push | 243 / 277 ms |
| Lever K=0 Talk lever Up | 226 ms |
| Lever K=1 Listen lever Down | 269 ms |
| Push K=0 BigButton | 295 ms |

UI 設計で「短押しを意識した動作」を HCI レベルで要求するのはほぼ不可能。binary 判定 (`state & 0x04` で long、`state & 0x02` で short) で十分。

### 3. VolUp / VolDn (slot 2/3) は press only / no release (Lever + Push)

Lever K=2 / K=3 単独短押し → state=0x01 1 event のみ、release event 配信なし。Push の slot 2/3 も同じ。

→ Volume up/down は EHX 内部で "press-trigger-once" volume tick action として処理される。**client は state=0x01 受信 1 回 = 1 tick** として扱い、release tracking を行わない。

Rotary の slot 2/3 は別物 (rotation event ストリーム = CW/CCW 各 tick)。

### 4. stale 0x07 stuck からの復帰

**Rotary push (slot 1) で 0x07 stuck (release event 抜け) が発生**することがある。stuck 中に再押下すると:

```
prev_state=0x07 → 0x03 (release tick 1) → 0x04 (long release) → 0x00
```

通常の `0x01 → ...` シーケンスではない。client press cycle tracker は **prev_state=0x07 から始まる event** を新規 press ではなく **stale long-action resolution** として識別すべき。

### 5. bit 3 (0x08/0x09) erratum (2026-05-14)

旧 hardware.md / kb#341 §A の "他キー同時アクション中の press marker" 仮説は **撤回**。

**verify_bit3.py で系統検証** (Rotary/Lever/Push、8 scenarios、~360 events) して **bit 3 = 0 を確認**:

- Rotary 同 face Talk + Listen 同時押し (~1ms 以内、4 cycle) — bit 3 立たず
- Lever 同 face 3-key 同時押し — bit 3 立たず
- Push VolUp + VolDn 50ms = Call Signal trigger ×3 — bit 3 立たず
- Cross-face、cross-panel、Talk hold + Vol press、急速 lever toggle — 全て bit 3 = 0

再現条件不明 (EHX function key 設定依存 / 別 fw / 観測誤認 のいずれか)。**実装は bit 3 を当面無視**。

## Phase B (key event handler) 実装パターン

```python
if state & 0x02:
    # Push event (短押し)
    fire_short_action()
if state & 0x04:
    # LongPush event (長押し)
    fire_long_action()

# stale 0x07 復帰
if prev_state == 0x07 and state in (0x03, 0x04, 0x00):
    handle_stale_resolution()

# VolUp/VolDn (slot 2/3 on Lever/Push)
if slot in (2, 3) and state == 0x01 and panel_type in (LEVER, PUSH):
    apply_volume_tick()
    # release を待たない
```
