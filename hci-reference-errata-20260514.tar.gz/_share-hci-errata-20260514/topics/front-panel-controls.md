# Front Panel Global Controls (rgn=0 K# mapping)

依存: `messages/MSG-318-319-321-key-events.md`、`topics/state-byte-bitmap.md`。

## 検証 (kb#341 §C、2026-05-12)

`verify_key_slots.py` で V12RD / V12LD / V12PD 三機種の前面ボタン・rotary を順次操作。**panel-type 非依存で同一 K# mapping** 確認。

| K# (rgn=0) | 制御 | 配信内容 |
|---|---|---|
| **K=0** | LS Main Levels push (上 rotary 押下) | press / release のみ (回転 tick は配信されず panel-local) |
| **K=1** | Aux Levels rotation tick | 短い PRESS (各 tick で 1 イベント) |
| **K=2** | Mic On ボタン | press / release |
| **K=3** | Headset Select ボタン | press / release |
| **K=4** | Shift Page ボタン | press / release。長押 (>500ms) で `rgn=1 page=9` 系 RELEAS バーストも発火 |
| **K=5** | Menu ボタン | press / release。入退室時 matrix が `page=56/57` 等の全 latch 状態を bulk RELEAS で sync |
| **K=80** | Aux Levels **LongPush** (= Alt Text 表示トリガ) | state=0x07 で LongPush 確定、解放まで持続 (K=1 短押しと別系統 emit) |

## 特性

- panel-type (Rotary / Push / Lever) に依らず **同じ K# 値で同じ制御** が割り当てられる
- `rgn=0` は **panel-global control 専用 region** (face 系 `rgn=1, 2` とは完全分離)
- **LS Main Levels rotation は HCI に届かない** (panel local 処理)
- 長押し系 (Shift Page menu / Menu mode entry) で matrix 側 proxy state **bulk sync** が発生

## Region 2 イベント

Shift Page (EHX 機能) が active な時、`rgn=2` イベントが配信される。EHX の shift map 切替と整合。配信される region 番号で識別可。

## 実装ヒント

GUI / Stream Deck client で「panel の Mic On / Headset / Shift Page」を検知したい場合は `rgn=0` の特定 K# event を subscribe。face button (rgn≥1) と完全に分離して処理する。
