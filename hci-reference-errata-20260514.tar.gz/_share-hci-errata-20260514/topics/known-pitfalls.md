# 既知の落とし穴 (開発開始時に一読推奨)

`raw/hardware-md-snapshot.md` §「既知の落とし穴」より抜粋 + 解説。

## 1. FLAGS bit 位置は仕様書 §4.2 の文章で判断しない

実例 (`0x34` / `0x35` / `0x25` / `0x24`) で逆引きすること。詳細: `topics/frame-format-and-flags.md`。

## 2. MSG 184 per-port stride は動的

`stride = 73 + 12 * n_exp`。本機実測 n_exp=21 → stride=325。他環境で異なる可能性。**動的計算すること**。詳細: `messages/MSG-183-184-port-info.md`。

## 3. HCI slot は configsoft slot から +1 ずれ

```
HCI slot N  ⇔  configsoft slot (N-1)
```

`messages/MSG-183-184-port-info.md` 参照。

## 4. `panel_type` (MSG 184) と Port Function (configsoft) は別管理

- panel_type = **live な物理ハードウェア**
- Port Function (configsoft) = EHX 設定

**両者は一致しないことがある**。物理判別は **MSG 184 panel_type を信頼**。詳細: `messages/MSG-183-184-port-info.md`、`topics/V-Series-panel-structure.md`。

## 5. 3RDPARTY assignment は HCI 不可

EHX configsoft で **事前設定が必須**。HCI から assign の追加・変更はできない。MSG 314/315 で読み出すのみ。詳細: `messages/MSG-314-315-proxy-display-get.md`。

## 6. Talk & Listen Label は UTF-16-BE で decode

LE ではない。`hci_client.py` の parser 参照。

## 7. Stream Deck SDK は v2.1.0

旧 v0.7.x は存在しない (T-hci-002 で確認)。新規 plugin 開発時は v2.1.0 SDK を使う。

## 8. PyInstaller ビルドには `--hidden-import=hci_client` 必須

Python client を PyInstaller で固める場合、`hci_client` module が動的 import されることがあるため明示指定が必要。

---

## 追加 (2026-05-12〜2026-05-14 補遺)

### 9. Long-push 閾値は ~200-280ms (HCI 層)

EHX UI のデフォルト 500-800ms より大幅に短い。**UI 設計で「短押しを意識した動作」を期待しない**。詳細: `topics/state-byte-bitmap.md` §2。

### 10. VolUp/VolDn (slot 2/3) は press only

Lever / Push 共通。release event 来ない、tick action として処理。詳細: `topics/state-byte-bitmap.md` §3。

### 11. MSG 17 delete ≅ MSG 38 level=0 (本 fw)

Crosspoint 削除は MSG 38 level=0 で行う。MSG 17 direction=0 を送っても entry は消えず level=0 で残る。詳細: `messages/MSG-017-action.md`、`messages/MSG-038-set-xpt-level.md`。

### 12. Field Trial fw で Role status=0 (Free) は always reject

MSG 390 で role 解放できない。**EHX Map Download で抜く** のが唯一の解放手段。詳細: `messages/MSG-388-389-390-role.md`。

### 13. HCI port 多重 listener、stale で 52001 拒否される

52002, 52003 へ fallback する client 実装が必要。詳細: `topics/connection-and-ports.md`。

### 14. stuck 0x07 が起きうる (rotary push slot 1)

復帰 sequence は `0x07 → 0x03 → 0x04 → 0x00` (通常の `0x01 → ...` でない)。詳細: `topics/state-byte-bitmap.md` §4。

### 15. V12PD K=0 BigButton 長押し時 release event 来ない

`0x07` で stuck (verify_bit3.py 観測)。client は `state & 0x04` 受信時点で long action 完了とみなし release を待たない実装が安全。詳細: `raw/kb-344-bit3-erratum.md` §E。

### 16. MSG 1 broadcast はヘッダ非標準 (MAGIC 無し)

MSG 1 受信時の parser で MAGIC をチェックして reject しないこと。msg_id=1 を特別扱いする。詳細: `messages/MSG-001-broadcast-system.md`。
