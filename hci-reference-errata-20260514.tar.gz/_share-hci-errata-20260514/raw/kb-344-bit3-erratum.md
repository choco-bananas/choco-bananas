﻿# bit 3 (0x08/0x09) 再現性検証 + 新発見 errata (2026-05-14)

検証ツール `work/ehx-gui-mockup/verify_bit3.py` で MSG 321 state byte の bit 3 trigger 条件を系統的に再現試行。Rotary (VI-PNL-12R) / Lever (VI-PNLB-12L) / Push (V12PD / E-IPA_IVC) 3 panel タイプ、8 scenarios、~360 events を収集 (jsonl: `work/journals/phase-c-state-bit3.jsonl`、本検証ジャーナルはローカル限定)。

## A. bit 3 hypothesis 撤回

旧記述 (hardware.md / kb#341):
- `0x08`: bit 3、V12LD multi-key 時に観測 (要追加検証)
- `0x09`: bit 0+3、他キー同時アクション中の press marker (2026-05-12 V12RD/PD multi-key 検証で再現確認)

**2026-05-14 検証では全 8 scenarios で bit 3 = 0**:
- A1-rotary-short: 単独短押し、Rotary 全 slot
- A1-rotary-retry: タッチ感短押し再試行
- A1-rotary-cross-face: face 1 全 slot
- A1-push-short: V12PD 単独
- B1-pd-callsignal: V12PD VolUp+VolDn ~50ms 同時 (×3 trials)
- B2-rd-talk-listen: Rotary Talk+Listen ~1ms 同時 (×4 cycles) + Talk hold + rotation
- A1-lever-short: Lever 単独
- B-lever-volup-voldn: Lever VolUp+VolDn ~50ms 同時 (Call Signal trigger pattern)
- B-lever-talk-volup: Lever Talk hold + VolUp / VolDn / cross-face Talk overlap
- C-lever-rapid-toggle: 急速 Talk/Listen lever toggle + 3-key concurrent

**結論**: 旧 hypothesis "他キー同時アクション中の press marker" は **再現不可** につき撤回。再現条件は不明 (EHX function key 設定 / firmware バージョン / panel 型番依存 / 観測時のキー configuration / 観測誤認 のいずれか)。Phase B 実装では bit 3 を当面無視。

## B. 新発見: Long-push 閾値 ~200-280ms (panel-type 非依存)

旧 hardware.md "~150-200ms" よりやや長い実測値 (verify_bit3.py jsonl 計測):

| Panel | Key | 計測 long-push 到達時間 |
|---|---|---|
| Rotary K=0 Talk button | cycle 1 / 2 | 218ms / 330ms |
| Rotary K=1 Rotary push | cycle 1 / 2 | 243ms / 277ms |
| Lever K=0 Talk lever Up | cycle 1 | 226ms |
| Lever K=1 Listen lever Down | cycle 1 | 269ms |
| Lever K=4 face1 Talk Up | cycle 1 | 195ms |
| Push K=0 BigButton | cycle 1 | 295ms |

**重要**: EHX UI の "Long Push" 設定はデフォルト 500-800ms だが、HCI 層では **~250ms** で 0x07 (LongPush 閾値到達) が emit される。「タッチ感」の短押しでも意図せず long として判定されやすい。

→ **GUI / Stream Deck 実装で「短押し」を意識した UI 設計は HCI 上ではほぼ無意味**。`state & 0x04` (long bit) と `state & 0x02` (short bit) の binary 判定で十分。

## C. 新発見: VolUp/VolDn (slot 2/3) は press-only on Lever + Push

A1-lever-short / B-lever-volup-voldn / A1-push-short / B1-pd-callsignal で確認:

- **Lever VolUp K=2**: 単独短押し → state=0x01 1 event のみ、release event 配信なし
- **Lever VolDn K=3**: 同様
- **Push VolUp K=2 / VolDn K=3**: 同様

これは Rotary slot 2/3 (= rotation event ストリーム、kb#341 §J) とは異なる。Lever/Push の VolUp/VolDn は dedicated 物理ボタンだが、**EHX 内部で "press-trigger-once" volume tick action として扱われ HCI 層には release が不要**と判断される模様。

実装上: Phase B client では slot 2/3 (Lever/Push) は **state=0x01 受信 1 回 = 1 tick** として処理し、release tracking を行わない。

## D. 新発見: stale 0x07 stuck からの復帰シーケンス

B2-rd-talk-listen cycle 1 / B-lever-talk-volup cycle 1 で観測:

シナリオ: K=1 (Rotary push or Listen lever) が前 scenario で 0x07 (LongPush 到達) に達したが release 受信せず → 内部状態 0x07 のまま stuck。新 scenario でユーザーが新たに press 操作した時:

```
prev_state=0x07 → 0x03 (down + push bit、release tick 1) → 0x04 (long release confirmed) → 0x00 (idle)
```

通常の `0x01 → 0x07 → 0x04 → 0x00` シーケンスではなく、`0x03 → 0x04 → 0x00` の 3-event 復帰シーケンスで配信される。bit 0 (down) はずっと立ったまま再 press と認識されない。

→ Phase B client では `prev_state=0x07` の event を **新規 press ではなく stale long-action resolution** として扱う必要あり (現在の gui_mockup.py `_press_state` tracker は 0x07 stuck をハンドルしているがこの復帰パターンの解釈ロジックを明示化推奨)。

## E. 既存 V12PD K=0 BigButton 長押し release 抜け 再観測

A1-push-short cycle 1: K=0 press → 49ms 0x01 → 295ms 0x07 (long threshold) → **以降 event 来ず** (release 受信せず)。

これは hardware.md 既存記述 (V12PD は slot 1 不配信、Call Signal で release 抑止) と整合する別現象 — BigButton long-push の release 抑止は新観測。

EHX 内部で BigButton long-push action が emit 完了したら release event は冗長として suppress している可能性。Phase B client では K=0 (Push) で `state & 0x04` (= 0x07 含む) を受信した時点で long action 完了とみなし、release を待たない実装が安全。

## F. 検証成果物

- `work/ehx-gui-mockup/verify_bit3.py` (検証ツール、scenario tag file 経由で外部制御)
- `work/ehx-gui-mockup/analyze_bit3.py` (jsonl → scenario-grouped timeline 出力)
- `work/journals/phase-c-state-bit3.jsonl` (~360 events、scenario_change 含む、ローカル限定)
- 旧 hardware.md state byte bitmap 表を 2026-05-14 確定版に更新

## G. 残課題

- bit 3 再現条件: EHX function key 設定 (Talk → AllCall, Talk → IFB Send, etc.) を変更して再試行
- 同 panel 種別の別 fw 検証 (Field Trial fw の挙動)
- V12LD (Lever V12 = VI-PNLB-12L、現状本日検証済) 以外の Lever 機種で確認
- V12PD BigButton 長押し release 抑止のロジック確認 (EHX firmware spec 確認候補)


