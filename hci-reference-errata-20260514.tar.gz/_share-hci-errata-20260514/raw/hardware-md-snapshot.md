<!-- Clear-Com matrix 機器仕様。MTC 業務機密 (検証機材構成)。常時遵守。 -->

# Hardware: Clear-Com Intercom Matrix (test rig)

> ⚠ 本ファイルは **confidential** (検証機材構成 — about.md 機密 4 領域の 1 つ)。
> 外部送信禁止。kb 投入は **`--group mtc --tags mtc-private,project-hci,...`** 経由のみ (Plan D 2026-05-14、kb#340)。shared kb への投入は絶対禁止。
> 機器に対する書込み系アクションを行う前に「運用上の注意」を必ず読み返す。

最終更新: 2026-05-11 (handoff-2026-05-11/HANDOFF.md より反映)。

## 機種 (test rig)

- 製造元: **Clear-Com**
- 系列: **Eclipse HX**
- CSU 構成 (EHX configsoft 表示):

| Card Slot | Card Type | 注目ポート |
|---|---|---|
| 1 | MVX-A16 | `1.1 (1)` V12RD (V 1RU Rotary)、`1.2 (2)` V12RD_2 (V 1RU Rotary)、`1.3 (3)` Direct "3"、`1.15 (15)` Direct "RTS-A"、`1.16 (16)` Direct "RTS-B" |
| 2–5 | MVX-A16 | (空) |
| 6 | E-IPA-64-HX | `6.1 (81)` V12IP1 (V 1RU Lever 設定だが物理は Rotary) |
| 7 | Empty | — |

- ファームウェア / EHX バージョン: **要確認** (handoff 時点では明示なし)

## ネットワーク

| 項目 | 値 |
|---|---|
| **CSU IP** | `192.168.0.150` |
| **制御ポート (HCI)** | `52001/tcp` / `52002/tcp` / `52003/tcp` ※ matrix は複数 HCI session を独立 port で listen している模様 (2026-05-13 検証: 52001-52003 同時開放確認)。前 session の TCP が stale 状態だと低番号 port が拒否される — その場合は次の port (52002, 52003, ...) を試す |
| 管理ポート (EHX 構成 / Web UI) | 要確認 |
| VLAN / セグメント | 要確認 |
| 疎通確認 | `Test-NetConnection 192.168.0.150 -Port 52001` |

## HCI API

- **バージョン**: HCI **2.0**
- **プロトコル**: TCP バイナリフレーム
  - Frame: `[START 0x5A0F][SIZE u16][MSG_ID u16][FLAGS u8][MAGIC 0xABBACEDE][SCHEMA 0x01][payload…][END 0x2E8D]`
  - Host→CSU の FLAGS は `0x08` 固定
  - CSU→Host の FLAGS bit: bit0=E (more follow), bit4=S (start of seq)。実例: 0x34/0x35/0x25/0x24
- **認証方式**: 要確認 (現状 open?)
- **公開ドキュメント**: HCI Reference 399G175 REVF.pdf (`notes/ehx-hci/study-notes.md`)
- **Read 系 (動作確認済)**: MSG 5/30 Panel Status / MSG 183/184 Port Info / MSG 321 Reply Key State
- **Write 系 (動作確認済)**: MSG 38 Set XPT Level / MSG 132 Delete Alias / MSG 244 Unicode Alias Add / MSG 312 Set Proxy LED / MSG 318 Key Auto Updates Enable
- **Write 系の運用ルール**: 本セッションでは**ユーザー確認後**のみ実行 (boundaries.md)
- **未実装**: MSG 314/315 (Proxy Display) / MSG 150/151 (XPT Level) / MSG 380/381 (Assigned Keys With Labels)

## Panel inventory (確認済 — MSG 184)

| HCI port | 物理 Panel Type code | Type Name | configsoft Label | Talk&Listen Label |
|---|---|---|---|---|
| 0 | `0x8016` | V-Series 1U Rotary | V12RD | `V12RD` |
| 1 | `0x8016` | V-Series 1U Rotary | V12RD_2 | `V12RD_2` |
| 80 | `0x8016` | V-Series 1U Rotary | V12IP1 | `V12IP1` |

**重要**: configsoft の「Port Function」列は configuration、MSG184 の `panel_type` は **物理接続パネル種別**。両者の不一致時は **MSG184 panel_type を信頼** (ユーザー指示)。

## Slot / Port 対応

```
HCI slot N  ⇔  configsoft slot (N-1)
HCI slot 2  →  HCI ports 0..15    (= configsoft slot 1, ports 1..16)
HCI slot 7  →  HCI ports 80..95   (= configsoft slot 6, ports 81..96)
port = (slot - 2) * 16 + offset    # HCI slot 1-based, port 0-based
探索範囲: slot 2..20
```

## V-Series Region / Face / Key 番号体系

参照: `EclipseHX_Logic_InstructionManual-399G266B.pdf` Section 4 Appendix C "Key Numbering on Panels" (p136-141)、図は `notes/handoff-2026-05-11/_logic-ch4-pages/fig_<MODEL>.png` に展開済。

### 基本構造

```
Panel  →  Region (2x3=6 face、例外的に 2x2=4 face)  →  Face  →  Key (4 個)
```

| レベル | 単位 | 番号付け |
|---|---|---|
| Panel | 1 物理パネル | HCI port 番号で識別 |
| **Region** | 通常 **2 行 × 3 列 = 6 face**、例外 **2 行 × 2 列 = 4 face** | **下段→上段、左→右** で 1-origin |
| Face | 物理キー面 (label + ボタン) | local_face = local_r * 3 + local_c (canonical 2×3 index、0..5) |
| **Key** | 1 つの key# (HCI) | **全 V-Series 機種で 4 keys/face** (stride=4) |

### Panel 種別ごとの region 配置 (Logic Ch4 Appendix C 由来)

| Model | face grid | tile col widths | Region 配置 |
|---|---|---|---|
| **V12LD/PD/RD** (1U) | 2×6 | [3, 3] | R1(left 2×3), R2(right 2×3) |
| **V24LD/PD/RD** (2U) | 4×6 | [3, 3] | bottom: R1, R2 / top: R3, R4 (各 2×3) |
| **V32LD** (2U 32-Key) | 4×8 | [3, 3, 2] | bottom: R1, R2 (2×3), **R3 (2×2)** / top: R4, R5 (2×3), **R6 (2×2)** |
| **V Desk** (V12L/P/RDD) | 4×3 | [3] | bottom: R1, top: R2 (各 2×3) |
| **V12LDE/PDE/RDE** (1U Exp) | 2×6 | [3, 3] | R1, R2 (各 2×3) |
| **V16LDE** (1U Exp 16-key) | 2×8 | [3, 3, 2] | R1, R2 (2×3), **R3 (2×2)** |

### Key# 計算式 (全 V-Series 共通、stride=4)

各 region 内、canonical 2×3 layout に基づく:
```
key_base(local_r, local_c) = local_r * 12 + local_c * 4
                           = local_face * 4   (canonical local_face = local_r*3 + local_c)

talk_key       = key_base + 0   # KEY_SLOT_TALK
listen_key     = key_base + 1   # KEY_SLOT_LISTEN
volup_key      = key_base + 2   # KEY_SLOT_VOLUP
voldn_key      = key_base + 3   # KEY_SLOT_VOLDN
```

### Slot 意味 × Panel 種別 (実機検証済 2026-05-12)

各 face 内の 4 key slot は **意味が全パネル種別で共通**、物理実装のみ異なる:

| Slot | 意味 | Rotary (R*) | Lever (L*) | Push (P*) |
|---|---|---|---|---|
| +0 | **Talk** | **Talk button (rotary 横の小型物理ボタン)** ✓ (2026-05-13 解明) | スイッチ ✓ | **BigButton** スイッチ ✓ |
| +1 | **Listen** | **Rotary push (knob 押し込み)** ✓ | スイッチ ✓ | **未 emit** ✓ (HCI に届かない、MSG 315 proxy entry も登録なし) |
| +2 | **VolUp** | Rotary CW 回転 ✓ | ボタン ✓ | ボタン ✓ |
| +3 | **VolDn** | Rotary CCW 回転 ✓ | ボタン ✓ | ボタン ✓ |

**重要**: V-Series 1U Rotary (V12RD/VI-PNLB-12R) の face は **「rotary knob」と「Talk button」の 2 物理入力** で構成。Rotary を 1 つの knob と誤認しがちだが、Talk ボタンが knob 近傍に別途配置されている。

### Rotary panel での Talk + Rotary 結合動作 (IFB send level adjust)

UserGuide §2.1 の「Talk + Rotary で IFB send level」は HCI 上は **2 つの独立 event** として届く:

```
t=0     K=0 PRESS 0x01     ← Talk button 押下
t=200ms K=0 RELEAS 0x02    ← Push event 確定 (matrix が短押と判定、ただし user は continue holding)
t=300ms K=2 PRESS 0x01     ← rotation CW
...
```

EHX は **Talk が hold 中 (state bit 0 down) + rotation event** という時間窓パターンを内部で検知して IFB send level adjust を発火する模様。client から再現する場合は同等の event 並びを host 経由で送る必要あり (要追加検証)。

V12LD / V12PD を 192.168.0.150 port 1 に物理接続し、全 face × 全 slot で MSG 321 key event を観測して検証 (2026-05-12)。V12PD は slot 1 (K=1,5,9,13,17,21) を **一切配信せず**、MSG 315 proxy entry 数も Lever/Rotary の半数 (5 vs 10) で整合。

### HCI 層と EHX 上位機能の境界 (実機観測 2026-05-12)

**MSG 321 の state byte は単純な make/break ではなく bitmap** (旧推測表は 2026-05-14 確定版 → 下記「state byte bitmap 解読」セクション参照)。1 物理押下で複数 state イベントが届く。**bit 3 (0x08/0x09) は再現条件不明 (旧記述撤回)、Phase B 実装では当面無視**。

考察: matrix 側で **Push / LongPush / Action 判定が行われ、結果が state bit として配信** されている。client 側で make→break 経過時間を計測する必要はない (`state & 0x04` で long 判定)。

### 補助観察 (2026-05-12)

- `rgn=0` で K=2/K=3 イベントが散発 → panel 前面の **LS Main Levels rotary / Aux Levels** 等の panel-global 制御と推測。3RDPARTY 表示とは無関係
- Region 2 イベントは Shift Page (EHX 機能) と整合、配信される region 番号で識別可

### Front panel global controls (rgn=0 K# 枠、V12RD/V12PD で同一確認 2026-05-12)

`verify_key_slots.py` で両機の前面ボタン・rotary を順次操作した結果:

| K# (rgn=0) | 制御 | 配信内容 |
|---|---|---|
| **K=0** | LS Main Levels push (上 rotary 押下) | press / release (回転 tick は配信されず panel-local) |
| **K=1** | Aux Levels rotation tick | 短い PRESS (各 tick で 1 イベント) |
| **K=2** | Mic On ボタン | press / release |
| **K=3** | Headset Select ボタン | press / release |
| **K=4** | Shift Page ボタン | press / release。長押 (>500ms) で `rgn=1 page=9` 系 RELEAS バーストも発火 |
| **K=5** | Menu ボタン | press / release。入退室時 matrix が `page=56/57` 等の全 latch 状態を bulk RELEAS で sync |
| **K=80** | Aux Levels **LongPush** (= Alt Text 表示トリガ) | state=0x07 で LongPush 確定、解放まで持続 (K=1 短押しと別系統 emit) |

特性:
- panel-type (Rotary / Push / Lever 多分) に依らず **同じ K# 値で同じ制御** が割り当てられる
- `rgn=0` は **panel-global control 専用 region** (face 系 rgn=1, 2 とは完全分離)
- LS Main Levels rotation は HCI に届かない (panel local 処理)
- 長押し系 (Shift Page menu / Menu mode entry) で **matrix 側 proxy state bulk sync** が発生

### Call Signal の HCI 表現 (2026-05-12 検証)

EHX の Call Signal 機能 (panel→相手に「呼び出し」シグナルを送る) は機種別に下記のように発火:

| 機種 | トリガ動作 | HCI 上の emit |
|---|---|---|
| V12PD (Push) | face の **VolUp + VolDn 同時押** | K=base+2 と K=base+3 が ~50ms 以内連続 PRESS (RELEAS は配信されない) |
| V12RD (Rotary) | face の **rotary push 長押** | K=base+1 (slot 1) の標準 LongPush シーケンス (0x01→0x07→0x04→0x00) |

**いずれも Call Signal 固有 HCI event は無く**、EHX 側が同時押 / 長押のパターンを検出して内部 (audio + signal) を起動する。Client 側でこれらを区別したい場合は同時押 / 長押の **入力パターンを HCI イベント列から検出する必要**がある (matrix 任せでは無く)。

これらは MSG 318 Auto Updates subscribe 中のみ届く。3RDPARTY 表示 (MSG 315) には現れない。

### state byte bitmap 解読 (2026-05-14 全 panel タイプ verify_bit3.py 系統検証で更新)

Rotary (VI-PNL-12R) / Lever (VI-PNLB-12L) / Push (V12PD/E-IPA_IVC) 3 タイプで **短押し / 長押し / 同時押し (~1ms)** / **Call Signal トリガパターン** / **stale state 復帰** を系統的に検証 (work/journals/phase-c-state-bit3.jsonl、~360 events、8 scenarios):

| state | bits | 意味 |
|---|---|---|
| `0x00` | — | idle / clean (debouncing 完了) |
| `0x01` | bit 0 | 物理スイッチ **down** (押下開始) |
| `0x02` | bit 1 | **Push** event (短押し release、action fired) |
| `0x03` | bit 0+1 | down + Push 同時 — **stale 0x07 復帰の最初の release tick** (新解釈、後述) |
| `0x04` | bit 2 | **LongPush** event (長押し release、long action fired) |
| `0x07` | bit 0+1+2 | **LongPush 閾値到達** (~200-280ms hold 後)、まだ down |
| `0x08` | bit 3 | **再現せず — 不明** (2026-05-14 全パターンで観測不可、旧記述は erratum) |
| `0x09` | bit 0+3 | **再現せず — 不明** (同上) |

#### bit 3 (0x08/0x09) について (2026-05-14 erratum、要再調査)

旧記述 (2026-05-12 観測時の hypothesis): "他キー同時アクション中の press marker"。

**2026-05-14 系統検証では再現不可**:
- Rotary 同 face Talk + Listen 同時押し (~1ms 以内、4 cycle) — bit 3 立たず、両者 normal cycle
- Lever 同 face Talk lever + VolUp button + VolDn button 3-key 同時押し — bit 3 立たず
- Push VolUp + VolDn (~50ms = Call Signal trigger) ×3 — bit 3 立たず (press のみ配信、release 抜けは確認)
- Cross-face、Cross-panel、Talk hold + Vol press、急速 lever toggle 全パターンで bit 3 = 0

旧 hypothesis を撤回。再現条件不明 (EHX function key 設定依存 / 特定 fw / 観測誤認 のいずれか)。**実装は bit 3 を無視する方向で先へ**、再現条件が判明したら再記載する。

#### Long-push 閾値 (新発見、~200-280ms 全 panel 共通)

実観測:
- Rotary Talk button (K=0): 218ms で 0x07 (cycle 1)、330ms (cycle 2)
- Rotary Rotary push (K=1): 243ms (cycle 1)、277ms (cycle 2)
- Lever Talk lever Up (K=0): 226ms
- Lever Listen lever Down (K=1): 269ms
- Push BigButton (K=0): 295ms

→ **HCI 層の long-push 閾値 ≈ 200-300ms** (EHX UI のデフォルト 500-800ms より遥かに短い)。**ユーザーが「タッチ感」で短押しすると意図せず long-push になりやすい**。UI 設計上は `state & 0x04` を long、`state & 0x02` を short として扱うのが正解 (時間計測不要)。

#### stale 0x07 stuck → 復帰シーケンス (新発見)

**Rotary push (slot 1) で 0x07 stuck (release event 抜け) が発生**することがある。stuck 中の key を再押下すると以下のシーケンスで復帰:

```
prev_state=0x07 (stuck) → 0x03 (release tick 1) → 0x04 (long release) → 0x00 (idle)
```

つまり通常の `0x01 → ...` シーケンスではなく、`0x03 → 0x04 → 0x00` という **stale 解決パターン** で配信される。Phase B 実装の press cycle tracker (`_press_state[key_id]`) は **prev_state=0x07 から始まる event** を **新規 press ではなく stale resolution** として識別すべき。

#### VolUp / VolDn ボタン (slot 2/3) は press only / no release (Lever + Push、新発見)

Lever K=2 (VolUp) / K=3 (VolDn) 単独短押し → state=0x01 1 event のみ配信、**release event (0x02/0x00) が来ない**。Push の slot 2/3 でも同じ挙動を確認。

→ Volume up/down ボタンは **EHX 内部で "press-trigger-once" action として扱われ**、HCI 層には release が不要と判断され配信されない。Phase B client では VolUp/VolDn の処理は **state=0x01 単発受信で 1 回の volume tick** として扱う (release tracking 不要)。

Rotary の slot 2/3 は別物 (rotation event ストリーム、kb#341 §J)。

### 重要な含意

**HCI 層で Push / LongPush を区別済み** — client 側で make→break 経過時間を計測する必要なし。`state & 0x04` で LongPush 判定。これは EHX の "Push" / "Long Push" function key 設定と直接対応する。

典型遷移:
- 短押し (Talk/Listen): `0x01 → 0x02 → 0x00` (down → Push event → idle)
- 長押し (Talk/Listen): `0x01 → 0x07 → 0x04 → 0x00` (down → LongPush 到達 → LongPush release → idle)
- VolUp/VolDn (Lever/Push): `0x01` 1 event のみ (release 配信なし、tick action として処理)
- stale 復帰: `prev=0x07 → 0x03 → 0x04 → 0x00`

Phase B (key event handling) では `state & 0x02` を Push、`state & 0x04` を LongPush として action dispatch するだけで十分。bit 3 (0x08/0x09) は当面無視。

### 2×2 region の key# layout (V16LDE/V32LD の R3/R6)

2×2 region は canonical 2×3 layout の最右列 (local_c=2) を欠いた形:
```
local_face 0 (K base 0)    local_face 1 (K base 4)    [local_face 2 absent]
local_face 3 (K base 12)   local_face 4 (K base 16)   [local_face 5 absent]
```

### 実機 V12RD_2 (port 1, 2×6) 検証 (2026-05-11)

| EHX 位置 | grid(r,c) | (region, local_face) | 期待 key# | 実観測 (MSG 315) |
|---|---|---|---|---|
| R1C1 | (0,0) | (1, 0) | 0..3 | rgn1 K=0,1 ✓ |
| R1C2 | (0,1) | (1, 1) | 4..7 | rgn1 K=4,5 ✓ |
| R1C5 | (0,4) | (2, 1) | 4..7 | rgn2 K=4,5 ✓ |
| R2C2 | (1,1) | (1, 4) | 16..19 | rgn1 K=16,17 ✓ |
| R2C5 | (1,4) | (2, 4) | 16..19 | rgn2 K=16,17 ✓ |

### 補足事項

- **Region 番号の bottom-up 順** は Logic Ch4 図で確認 (V24RD: 下段 R1/R2、上段 R3/R4)。1 行パネル (1U) では only-row のため影響なし
- **page**: MSG 315 の page byte は main page = 0、subsequent shift pages = 1, 2, 3, ... (Logic Ch4 序文より)
- HANDOFF.md errata "region H→B + drop pad" は別文脈 (V-Series IrisX 系 Iris display) の可能性、未解明 — 要追跡

## Level ↔ dB 変換 (MSG 38 / MSG 40 / MSG 151 共通)

HCI Reference §4.18 Appendix C で定義 (実機 self-talk = 0xCC = 204 で +0.00 dB を 2026-05-12 確認):

```python
LEVEL_MAX   = 255
LEVEL_0DB   = 204
LEVEL_MUTE  = 0
DB_PER_TICK = 0.355

# 線形換算
db    = (level - LEVEL_0DB) * DB_PER_TICK     if level > 0 else -inf
level = round(LEVEL_0DB + db / DB_PER_TICK)   # clip to [0, 255]
# 1tick ≒ 0.355 dB、9tick ≒ 3.2 dB (rotary_volume_ctrl.py default step)
```

## XPT 取得経路 (MSG 39/40 vs MSG 150/151)

| Msg pair | クエリ基準 | 返り | self-talk | unsolicited 配信 |
|---|---|---|---|---|
| **MSG 39 / 40** | destination port | (src, level) 一覧 | 返る (※) | **MSG 38 後に auto-broadcast** (確認 2026-05-12) |
| **MSG 150 / 151** | source port | T/L flag 付き (両方向 + self) + level | 返る | xpt add/delete 後の unsolicited あり (hci-verifier 確認) |

※ 2026-05-12 早朝の実機検証で「MSG 39/40 は self-talk を返さない」と記録したが、追試で **host-set self-xpt は MSG 40 で返る** ことを確認。前回観測時はそもそも xpt が存在しなかった (panel 操作で MSG 321 のみ発火、xpt 生成は HCI client 任せ) と思われる。

実装: `hci_client.py` の `request_xpt_levels()` (MSG 39) と `request_xpt_and_levels()` (MSG 150) を提供。`HciClient.discover()` は MSG 150 を V-Series 各 source port に対して自動送信し、`_xpt_levels` dict にキャッシュする。MSG 40 auto-broadcast も同じ dict を更新する。

## MSG 38 (Set Crosspoint Level) 実機検証 (2026-05-12)

`verify_msg38_write.py` で書込み動作を実機検証完了:

| 送信 | 受信 (MSG 40 unsolicited) | 解読 |
|---|---|---|
| `dst=1 src=1 level=0xCC` | `src=1 dst=1 level=204` | **+0.00 dB** ✓ (LEVEL_0DB) |
| `dst=1 src=1 level=0xD5` | `src=1 dst=1 level=213` | **+3.19 dB** ✓ (spec 式 (213-204)*0.355=3.195) |
| `dst=1 src=1 level=0x00` | `src=1 dst=1 level=0` | **MUTE** ✓ |

確定事項:
- MSG 38 frame format (22 bytes、count=1 + dest+src+level の triple) で正常動作
- **MSG 40 は matrix からの unsolicited broadcast** で MSG 38 設定後に届く → client 側は polling 不要、`_on_pkt` で受け取るだけで latest state を track 可
- **level=0 は soft MUTE** — MSG 40 reply に依然存在、level=0 として表示
- spec §4.18 の dB 換算式 `(level - 204) × 0.355` 完全一致

## MSG 17 (Crosspoint Actions = add/delete) 実機検証 (2026-05-12)

`verify_msg17_delete.py` で実装 + 実機検証:

- MSG 17 builder (bit-packed Word 0..3、spec §4.13.2 準拠) は **unit test 完備、protocol レベル正常**
- 実機での挙動: MSG 17 direction=0 (delete) 送信後も xpt は **MSG 40/151 reply に level=0 で残存**。entry の完全消失は観測できず
- 同 matrix で参照実装 `rotary_volume_ctrl.py` も **MSG 17 を使っていない** — 実用上 MSG 38 level=0 のみで運用
- 推論: 当 matrix firmware では「xpt delete = level=0」と等価実装、true delete path は HCI 上に存在しないか別 MSG (要追加調査) — Phase B+ で深堀候補

### 暫定運用ルール

- **GUI / client から xpt を「削除」したい場合は MSG 38 level=0 (MUTE) を送る** で十分。MSG 17 は protocol 完備だが現状実機効果なし
- `HciClient.delete_xpt()` は将来 firmware 拡張で有効化される可能性あり、API は維持

### MSG 151 payload 構造 (実機検証済)

```
u16 count
repeat count times:
  u16 flags_port:  bit15=Monitored (header), bit14=Talk (monitor→port),
                   bit13=Listen (port→monitor), bits9..0=Port (10-bit)
  u16 level
```
- M=1 entry が monitor port 宣言、後続の M=0 entry が relation
- T+L 同時 set は self-talk または bidirectional (parser でデドゥープ)

実機例 (V12RD_2 自己 talk 中):
```
payload: 00 02 80 01 00 00 60 01 00 CC
         count=2, entry1: M=1 port=1, entry2: T+L port=1 level=0xCC
解読:    monitor=1, self xpt at +0.00 dB
```

## 既知の落とし穴 (HANDOFF.md §8)

1. **FLAGS bit 位置は仕様書 §4.2 の文章で判断しない** — 実例 (0x34/0x35/0x25/0x24) で逆引き必須
2. **MSG184 per-port stride** は `73 + 12 * n_exp`。本機実測 n_exp=21 → stride=325。他環境で異なる可能性あり、動的計算すること
3. **HCI slot は configsoft slot +1 ずれ**
4. **`panel_type` (MSG184) と Port Function (configsoft) は別管理**。panel_type を信頼
5. **3RDPARTY assignment は HCI 不可** — EHX configsoft で事前設定必須
6. **UTF-16-BE で Talk&Listen Label を decode** (LE ではない)
7. **Stream Deck SDK は v2.1.0** (旧 v0.7.x は存在しない)
8. **PyInstaller ビルドには `--hidden-import=hci_client`** 必須

## 絶対定格 / 運用ルール

- **接続可能時間帯**: 平日 9:00〜18:00 (業務時間内)
- **接続トリガー**: 社内慣習として **必要時のみユーザーが物理的に端末を接続・電源投入**する。エージェントは独断で接続試行しない
- **エージェント側の動作規約**: ユーザーから「接続した」「実機検証可能」等の明示 signal を受けてから初めて TCP 接続を行う。それまでは parser/builder の単体テスト + 合成 payload による検証に留める
- 接続セッション数の上限: **要確認**
- 認証失敗ロックの仕様: **要確認**
- 構成変更前の手順: **要確認** (バックアップエクスポート、変更通知ルート)
- 実機検証は **会社PC のみ** (sync-policy §1)

## 認証情報

実値はここに書かない (現状そもそも認証フローを把握していない)。確定したらこのファイルに **値ではなく所在のみ** を記す。

## 接続テストのテンプレ (PowerShell)

```powershell
$matrixIp = '192.168.0.150'
$ctrlPort = 52001
Test-NetConnection $matrixIp -Port $ctrlPort

# 詳細な HCI ハンドシェイクは hci_client.py (work/ehx-gui-mockup/) または
# hci.ts (work/ehx-vol-ctrl/src/) のクライアント実装を流用
```
