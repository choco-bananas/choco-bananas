﻿# HCI Reference Errata 補遺 (2026-05-12/13/14 検証分、kb#337 への追加)

出所: 会社 PC `ws_company` MTC HCI project session が V12RD/V12LD/V12PD physical を順次接続して検証。Median CSU 192.168.0.150。kb#337 (v0.3.0 時点 36 件) 以降の追加発見をここに集約。

## A. state byte (msg 321) bitmap 完全解読

旧 kb#337 entry 23 は state=0x01/0x07 のみ観測で unclear。短押し + 長押し (2-3秒) を全 face で試した結果、bitmap 構造を解明:

| state | bits | 意味 |
|---|---|---|
| 0x00 | — | idle / clean release 確定 |
| 0x01 | bit 0 | 物理スイッチ down |
| 0x02 | bit 1 | **Push event** (短押 action 発火) |
| 0x03 | bit 0+1 | down + Push 事象 (transient release) |
| 0x04 | bit 2 | **LongPush event** (長押 action 発火) |
| 0x07 | bit 0+1+2 | LongPush 閾値到達 (~200ms hold)、まだ down |
| 0x08 | bit 3 | release with secondary flag (multi-key concurrent 時) |
| 0x09 | bit 0+3 | down + 他キー同時アクション marker |

含意: **HCI 層で Push / LongPush を区別済み**、client 側で時間計測不要。`state & 0x04` で LongPush 判定可。

典型遷移:
- 短押: 0x01 → 0x02 → 0x00
- 長押: 0x01 → 0x07 → 0x03 → 0x04 → 0x00
- (まれに 0x04 が抜け 0x07 → 0x03 → 0x00 になる、client は edge tracking で救う)

## B. V-Series 1U Rotary (V12RD) face = 2 物理入力構造

長らく単一 knob 構造と誤認していたが、実機 V12RD (VI-PNLB-12R) で **rotary knob + 別の小型 Talk button** の 2 入力構成と判明 (2026-05-13):

| Slot | 物理入力 | emit |
|---|---|---|
| +0 (Talk) | **Talk button** (small switch、rotary 横の独立ボタン) | K=base+0 |
| +1 (Listen) | Rotary push (knob 押し込み) | K=base+1 |
| +2 (VolUp) | Rotary CW 回転 | K=base+2 |
| +3 (VolDn) | Rotary CCW 回転 | K=base+3 |

「Talk + Rotary で IFB send level adjust」(V-Series UserGuide §2.1) は HCI 上は 2 独立 event (`K=0 hold` + `K=2/3` 個別)、matrix が時間窓パターンで内部解釈。

## C. Front panel global controls (rgn=0 K# 枠)

V12RD/V12LD/V12PD 三機種で同一 K# mapping を確認 (panel-type 非依存):

| K# (rgn=0) | 制御 | 配信内容 |
|---|---|---|
| K=0 | LS Main Levels push (上 rotary) | 押し込みのみ HCI 配信、rotation は panel-local |
| K=1 | Aux Levels short Push | 短押し action (Listen Again 等) |
| K=2 | Mic On ボタン | press / release |
| K=3 | Headset Select | press / release |
| K=4 | Shift Page | 短押 = main↔shift、長押 = shift menu |
| K=5 | Menu | press / release |
| K=80 | **Aux Levels LongPush** (= Alt Text 表示トリガ) | sustained event、K=1 と別系統 emit |

rgn=0 は panel-global 制御専用、face 系 rgn=1, 2 とは完全分離。LS Main Levels rotation は HCI に届かない (panel local 処理)。

## D. slot 意味 × panel 種別 完全表 (実機確認)

| Slot | Rotary (V12RD) | Lever (V12LD) | Push (V12PD) |
|---|---|---|---|
| +0 Talk | Talk button | スイッチ | BigButton |
| +1 Listen | Rotary push | スイッチ | **HCI 未 emit** (MSG 315 proxy entry も登録なし) |
| +2 VolUp | CW 回転 | ボタン | ボタン |
| +3 VolDn | CCW 回転 | ボタン | ボタン |

V12PD の MSG 315 proxies=5 (V12LD=10、V12RD=12) は slot 1 が物理不在のため。Push は BigButton 一個で Talk+Listen を兼ねる UI 設計。

## E. V-Series Region 構造 (Logic UserGuide Ch4 Appendix C p138-141 由来)

| Model | face grid | tile col widths | Region 配置 |
|---|---|---|---|
| V12LD/PD/RD (1U) | 2×6 | [3, 3] | R1(left 2×3), R2(right 2×3) |
| V24LD/PD/RD (2U) | 4×6 | [3, 3] | bottom: R1, R2 / top: R3, R4 (各 2×3) |
| V32LD (2U 32-Key) | 4×8 | [3, 3, 2] | bottom: R1, R2 (2×3), **R3 (2×2)** / top: R4, R5 (2×3), **R6 (2×2)** |
| V Desk (V12L/P/RDD) | 4×3 | [3] | bottom: R1, top: R2 (各 2×3) |
| V12LDE/PDE/RDE (1U Exp) | 2×6 | [3, 3] | R1, R2 (各 2×3) |
| V16LDE (1U Exp 16-key) | 2×8 | [3, 3, 2] | R1, R2 (2×3), **R3 (2×2)** |

- Region は **下段→上段、左→右** で 1-origin 番号付け
- 16/32-face モデルは末尾 region が 2×2 (3 列構造の最右列が物理欠落)
- Key# 計算: `key_base(local_r, local_c) = local_r * 12 + local_c * 4`、canonical local_face = local_r*3 + local_c
- 全 V-Series で 4 keys/face (HCI 内部 stride=4)

実機 V12RD_2 (port 1) で 5 face × 2 region (3RDPARTY 配置) が EHX 設定と完全一致 (2026-05-12)。

## F. MSG 17 (Crosspoint Actions) direction=0 ≅ MSG 38 level=0 (実機検証)

kb#337 entry 21 で MSG 17 bit layout 詳細。bit-packed builder を実装し、direction=0 (delete) で実機検証:

- 結果: xpt entry が消失せず **level=0 (MUTE) として MSG 40 reply に残存**
- 参考実装 `rotary_volume_ctrl.py` も MSG 17 を使わず MSG 38 only で運用
- **このファームでは「xpt delete」と「level=0 set」が等価実装** と推測
- 完全 entry 削除 path は別 MSG 経由かも (未解明)、要追加検証

実用ルール: **xpt 削除は MSG 38 level=0 (MUTE) で十分**、MSG 17 は protocol 完備するも実際の効果は MUTE と同じ。

## G. MSG 38 / 39 / 40 / 150 / 151 自動 broadcast 挙動

- **MSG 38 (Set XPT Level) 実行後、matrix が MSG 40 を unsolicited 自動 broadcast**。client polling 不要、subscribe 不要で `_on_pkt` で受信して latest state を track 可
- MSG 40 (Reply Crosspoint Level Status, by dest) は host-set self-talk (src=dst) を返す。旧記録 (2026-05-12 早朝) で「self-talk 返らない」と書いたのは当時 xpt が存在しなかっただけで、actual には返る
- MSG 151 (Reply Xpt and Level Status, by src) は T (monitor→other) / L (other→monitor) bit を payload entry に持ち、self-talk を 1 message で両方向取得可。kb#337 entry 24 の bit layout を補完: header entry (M=1) + relation entry (T=1 or L=1 or 両方) の pair 構造
- dB 変換式 `gain_dB = (level - 204) × 0.355` 完全一致 (level=0xD5=213 で +3.19 dB 観測)

## H. matrix HCI port 多重 listener (52001/52002/52003)

- Median CSU は **複数 HCI port listener を独立に開放** (52001, 52002, 52003 同時開放を確認)
- 前 session の TCP が stale (TCP keepalive timeout 未到達) で残ると、低番号 port が新規接続を拒否する
- 対処: 次の port (52002, 52003, ...) に fallback、client 実装で複数 port を順次試行する
- Black reset 後はクリアされるが、自然タイムアウト (~数分) でも解放される模様

## I. MSG 318 / 319 / 321 (Key Auto Updates) フレーム長

- MSG 318 payload: port_start(2) + port_end(2) + enabled(1) = 5 bytes、フレーム total **19 bytes** (旧 ehx-vol-ctrl の 21 bytes alloc + writeHeader(21) は末尾 garbage 含むバグ、本セッション 2026-05-12 修正済)
- MSG 321 は subscribe 中 unsolicited で全 panel 全 key event を flood する。disable は MSG 318 enabled=0 で
- 1 物理押下で **複数 state event** が連続発火 (down → continue → Push/LongPush → release path)。client は edge tracking して action dispatch

## J. MSG 312 (Set Proxy LED) "pad" の正体は mic byte

旧 ehx-vol-ctrl `buildSetProxyLed` の "pad" 命名は誤り、実は **mic flag** (0=disable、1=enable)。SIZE=24 bytes が正、26 bytes alloc は末尾 garbage。本セッション 2026-05-12 修正済。kb#337 entry 8 (silent rejection 仕様) + entry 21 (MSG 17 bit layout) 周辺の理解を補完。

## 関連

- kb#337 (errata カタログ v0.3.0 時点、本エントリの基底)
- kb#336 (HCI Reference 学習ノート)
- kb#338 (hci-verifier v0.3.0 設計概要)
- kb#340 (Plan D 運用ルール、本エントリ投入経路の根拠)


