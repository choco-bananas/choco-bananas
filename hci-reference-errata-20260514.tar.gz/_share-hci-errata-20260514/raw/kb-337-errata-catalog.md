# HCI Reference Errata カタログ (実機検証で確定した 36 件)

出所: hci-verifier v0.3.0 の `hci_verifier/errata.py` (2026-05-08 時点)。
実機 Median + MVX-A16 + E-IPA-HX + V12RD + V-Iris 12RD で 15 phase 検証済。
各エントリは Discrepancy データクラス由来:
- section: マニュアル該当節 / 領域
- claim: マニュアル記述
- observed: 実機での観察
- severity: blocker / major / minor / note
- workaround: 回避策 (あれば)

## 重要度別サマリ

- **blocker**: 0 件
- **major**: 11 件
- **minor**: 3 件
- **note**: 22 件

## 全エントリ

### 1. [MAJOR] v0.2.0 regression: _parse_key_pressed_status (msg 321) parser

**Claim**: v0.1.0 → v0.2.0 incorporated journal findings; should also have applied yesterday's msg 321 parser fix.

**Observed**: v0.2.0 ships verified_messages.py with the v0.1 buggy msg 321 parser still in place: it reads schema(B) + count(B) at offsets 0-1, but actual format is just count(B) at offset 0 followed by 7-byte entries (panel(h) region(B) page(B) key(B) state(B) latch(B)). v0.2.0 parser always returns count=0 entries=[] even when valid events arrive (Phase 11 captured 23 such events but parser saw all as count=0).

**Workaround**: Apply v0.1 fix: read count(B) at offset 0, then 7-byte entries starting at offset 1. Until then, callers must decode payload bytes manually to extract panel/region/key.

### 2. [MAJOR] v0.2.0 regression: build_set_proxy_display_state / build_set_proxy_indication_state

**Claim**: v0.1.0 → v0.2.0 incorporated journal findings; should also have applied the proxy message structure fixes.

**Observed**: v0.2.0 ships verified_messages.py with the v0.1 buggy structures still in place:
  - build_set_proxy_display_state uses 40-byte text fields (should be 20 bytes; 10 UTF-16-BE chars).
  - build_set_proxy_indication_state has region as H (2 bytes, should be B = 1 byte) plus an extra trailing padding byte.
These were verified-working fixes from yesterday's verification (Phase 8a/8b succeeded with the corrected versions and the matrix accepted them; the labels and LED states updated visibly).

**Workaround**: Re-apply the v0.1 fixes: 40s -> 20s, '>HHHBBBBBB' -> '>hhBBBBBB' for indication. Until then, the existing ad-hoc DIST/verify_proxy_led.py format is correct.

### 3. [MAJOR] §2 Overview — 'auto Reply CPU Status' after connect

**Claim**: 'When the reset sequence has been completed by the CSU, the protocol will attempt to establish the communications link. If valid packets are transferred without error, the CSU will then send an automatically generated Reply CPU Status message.'

**Observed**: On real Median, the first message after TCP open is NOT a Reply
CPU Status. It is a **Broadcast System Message (msg 1)** with an
ASCII log line such as:
    '07/05/26 16:50:00.907,60|TCP host 192.168.0.10 port 49789 opened err 255'
Note this is logged on EVERY connect, even when the host packet
was perfectly valid — 'err 255' appears to be a default code, not
a real error. A second broadcast follows shortly:
    'ADM TCP:192.168.000.010 connected'
After that, the first Reply Action Status (or other reply) is
what acks an actual host request — there is no spontaneous Reply
CPU Status.

**Workaround**: hci_verifier.HciClient.connect() now describes this accurately. The 'capture_post_connect' frame is the broadcast log, not CPU status. Use parse_broadcast_system_message() to extract the text.

### 4. [MAJOR] §3.1 (general) — MAGIC_NUMBER not documented

**Claim**: §3.1 does not mention any 'magic number' or 'tag' field for header validation.

**Observed**: All non-ping packets must include a 32-bit tag field set to 0xABBACEDE in the header. The matrix's host parser rejects packets where this value is wrong (parse_header in HCITrainingDemo checks 'if params[2] == 0xABBACEDE').

**Workaround**: hci_verifier.protocol.MAGIC_NUMBER

### 5. [MAJOR] §3.1.1 Broadcast System Message header layout

**Claim**: Same framing as other messages: start, size, msg_id, flags, tag (MAGIC_NUMBER 0xABBACEDE), schema, payload, end.

**Observed**: Broadcast System Message (msg 1) has a NON-STANDARD header.
The MAGIC_NUMBER is NOT present at the usual offset. After
start/size/msg_id/flags=0x30, the next 4 bytes are a category
filter code (commonly 0x0004023E or 0x0004017E), then 4 zero
bytes, then a NUL-terminated ASCII line, then end (0x2E8D).
Hosts must NOT reject these for missing MAGIC.

**Workaround**: hci_verifier.verified_messages.parse_broadcast_system_message() and parse_reply() handle this special case.

### 6. [MAJOR] §3.1.1 Packets Structure (framing description)

**Claim**: The 'message field' between length and end is described as '2 to 836 bytes of data', with no further structure documented in §3.1.

**Observed**: Verified packets have a *fixed 8-byte header inside the message field*: msg_id (16-bit) + flags (8-bit) + tag (32-bit, MAGIC_NUMBER=0xABBACEDE) + schema (8-bit). Hosts must include the magic number for the matrix to accept the packet.

**Workaround**: Build packets with hci_verifier.protocol.build_packet() which constructs the 12-byte header (start+size+msg_id+flags+tag+schema).

### 7. [MAJOR] §3.1.3 Ping Facility — example bytes

**Claim**: 'If the CSU receives a packet with a size of 10 message, thus: 5A 0F 00 10 00 00 2E 8D — it will be echoed back to the relevant Host.'

**Observed**: CONFIRMED ON REAL MEDIAN (May 2026, phase1-ping-buggy.jsonl):
Sending the documented 8-byte bytes does NOT produce an echo.
Instead the matrix logs an error and sends back a Broadcast
System Message (msg 1) containing ASCII text:
    '07/05/26 16:49:44.736,56|TCP host 192.168.0.10 port 49768 opened err 255'
The 'err 255' confirms the malformed packet was rejected.

The actual verified ping packet is:
  5A 0F 00 0A 00 00 00 00 2E 8D   (10 bytes, length=0x000A=10)
which echoes verbatim with ~60 ms RTT (phase1-ping-verified.jsonl).

**Workaround**: Use hci_verifier.protocol.VERIFIED_PING_BYTES or hci_verifier.verified_messages.build_ping().

### 8. [MAJOR] §4 silent rejection of malformed proxy requests (msg 312 / 316)

**Claim**: §4.5 'No messages are provided to inform the host that the message was not understood by the CSU.'

**Observed**: Confirmed empirically: when SET_PROXY_INDICATION (msg 312) is sent with the WRONG struct (e.g. region as 2-byte H instead of 1-byte B), matrix replies with msg 313 carrying flag=0x00 and payload count(h)=0 (no entries reported). Compare with a well-formed request which returns flag=0x00 and count=1+ with the entry data echoed. The only distinguisher is the payload count field; the flags byte alone does NOT signal success vs silent reject.

**Workaround**: After sending msg 312/316/etc. proxy requests, parse the reply payload count field. count==0 means request was not applied. Do not rely on flag bits for ack/nack detection.

### 9. [MAJOR] §4.151-4.154 Role configured_ep — semantics in Field Trial firmware

**Claim**: §4.152 'Configured Endpoint type: Panel type associated with the key configuration.'

**Observed**: Field Trial firmware: a role can only be allocated to a physical port if the role's configured panel type MATCHES the port's port-settings panel type. The physical panel actually connected (reported by msg 184 panel_type) is IRRELEVANT for this match. Example (2026-05-08): role 601 (UI '123') had to be changed to 'V-Series Rotary' to match port 2's port-setting 'V-Series Rotary', even though the physical panel at port 2 was a Lever (VI-PNLB-12L, msg 184 panel_type=0x8010). Allocation succeeded. 
Therefore configured_ep in msg 389 reflects the ROLE's configured panel type (set in EHX), not the panel_type of the currently-connected physical panel.

**Workaround**: When allocating a role via msg 390, ensure the role's configured panel type matches the target port's port-setting panel type. Use msg 184 to inspect physical hardware separately.

### 10. [MAJOR] §4.153 Role State Set — status=0 (Free) is rejected by Field Trial firmware

**Claim**: §4.153 says 'New Status: 0=Free, 1=Allocated From Pool'. Implies HCI host can transition either direction freely.

**Observed**: On Median Field Trial firmware (2026-05-08): msg 390 with status=1 (Allocate) succeeds (success=True in msg 391). msg 390 with status=0 (Free) ALWAYS returns success=False, regardless of phys_port value (tried 0, role-number, currently-allocated port, 0xFFFF). msg 398 Disconnect Session also does not free the role. Once a 'Role Session' starts, the only way to end it observed so far is via EHX Map Download with the allocation removed from the new map.

**Workaround**: Do not rely on msg 390 status=0 to release a role on Field Trial firmware. To release: re-download a Map from EHX without the role allocation. Track this as a firmware asymmetry, not a host-side bug.

### 11. [MAJOR] §4.46 Reply Port Info (msg 184) — primary source for physical panel type

**Claim**: §4.37 Reply Panel Status (msg 30) describes a panel_type field with 8 enum values (PANEL_GENERIC, antenna types, etc.).

**Observed**: msg 30 panel_type field is too coarse to distinguish VI-PNL-12R (Rotary) from VI-PNLB-12L (Lever) — both report as PANEL_GENERIC=1. The discriminating field is the 16-bit panel_type in §4.46 Reply Port Info (msg 184), which uses a different enum (0x8000-0x8204) covering specific hardware models. Empirical map (verified 2026-05-08):
  port 0 V12RD       -> 0x8016 V-Series 1U Rotary  (fw 4.11)
  port 1 VI-PNLB-12L -> 0x8010 V-Series 1U Lever   (fw 6.77)
  port 80 VI-PNL-12R -> 0x8016 V-Series 1U Rotary  (fw 5.43)
Naming rule: '12L' = Lever (0x8010), '12R' = Rotary (0x8016), B = Black variant (same code).

**Workaround**: Use hci_verifier.verified_messages.build_request_port_info(slot) + parse_port_info_reply(payload). Catalog: PANEL_TYPE_NAMES.

### 12. [MINOR] §4 Reply Action Status — host_ip field width

**Claim**: HCITrainingDemo's hxreply.ActionStatus declares host_ip_addr as a 16-bit H field.

**Observed**: On real Median (phase3-xpt-2to1.jsonl), the host_ip_addr is a
32-bit IPv4 address. After count(H) the next 4 bytes are the
IPv4 of the requesting host (e.g. C0 A8 00 0A = 192.168.0.10).
Then per-action data: action_type (H) + 4 packed words (8 bytes).
Total per action = 10 bytes, NOT 8.

**Workaround**: hci_verifier.verified_messages._parse_action_status() uses the correct 4-byte IPv4 layout.

### 13. [MINOR] §4 Request Remote Key Actions — 1-based vs 0-based panel

**Claim**: Manual addresses panels by port number; 1-based vs 0-based not explicitly stated for this message.

**Observed**: Training code (keys.py) explicitly converts the user-supplied 1-based panel number to 0-based before transmission (target = target - 1).

**Workaround**: hci_verifier.verified_messages.build_assign_keys() takes a 1-based panel number (matches manual addressing) and converts internally.

### 14. [MINOR] §4 Undocumented message IDs observed in normal operation

**Claim**: Manual §4 lists a fixed message catalogue.

**Observed**: Real Median emits messages not in the §4 catalogue:
  msg 5  REQUEST_PANEL_STATUS — useful for discovery (NEW)
  msg 30 REPLY_PANEL_STATUS — entry format port_lo/type/state/port_hi
  msg 98 REPLY_FRAME_STATUS — observed during xpt cycles
  msg 151 (0x97) — appears after xpt delete; semantics TBD
  msg 237 REQUEST_KEY_ASSIGN_STATUS / 238 REPLY_KEY_ASSIGN_STATUS
  msg 344 (0x158) — observed in proxy indication cycles
These are useful for system discovery but not formally specified.

**Workaround**: hci_verifier.verified_messages provides build_request_panel_status and parse_panel_status helpers.

### 15. [NOTE] EHX Map Download channel — separate from HCI

**Claim**: Manual focuses on HCI; EHX configuration changes are treated as out-of-band but their effects are not enumerated.

**Observed**: EHX modifies matrix configuration via a Map Download channel (separate TCP path on the matrix). On Map download we observe the matrix emit:
  - msg 8 (REPLY_CCF_FILE) x2 carrying 'New Configuration'     + matrix name 'H_Median' (CCF version notification)
  - msg 361 (UNKNOWN_361) one packet with payload '08 00     00 00' (semantics TBD)
  - many msg 1 broadcast log entries: 'process_map=== 0',     'Map download was valid - saving Map 1', 'Clear Local     Overrides...', 'Saving HXC to FLASH', 'NID HXC File     Saved', 'Map changed, new configuration loaded',     'ROLE SESSION START/END' (when role allocations     differ between old and new maps).
Role allocation/deallocation in Field Trial firmware happens through this channel, NOT via msg 390.

**Workaround**: When EHX is making configuration changes, expect msg 8 and msg 1 broadcast traffic; correlate with EHX log to interpret. Do not assume HCI is the only channel.

### 16. [NOTE] Periodic msg 363 heartbeat (entirely undocumented)

**Claim**: No mention of any periodic heartbeat in §3 or §4.

**Observed**: Once a host TCP connection is established, the matrix sends an
85-byte payload msg 363 (0x16B) every ~1 second. Header has
MAGIC + schema=0x02. Body starts with 01 4C 05 69 FC C? ?? ??
08 00 FF FF then mostly zeros. Likely connection-level keepalive
or system status. Hosts must drain these to avoid TCP buffer fill.

**Workaround**: hci_verifier.protocol.MsgId.HEARTBEAT_363 constant. HciClient.recv_until_msg_id(skip_noise=True) skips them automatically.

### 17. [NOTE] Server-to-host flag values (§3.1, §4 entirely undocumented)

**Claim**: The flags byte semantics for replies are not explicitly listed.

**Observed**: Captured server-to-host frames use these flag values:
  0x34 — normal reply (with MAGIC, schema=0x01)
  0x30 — Broadcast System Message (msg 1), no MAGIC
  0x10 — heartbeat (msg 363, 1 Hz, with MAGIC, schema=0x02)
  0x00 — empty replies (e.g. msg 313 SET_PROXY_INDICATION reply
         when the request changed nothing significant)
Bit 0x04 in 0x34 vs 0x30 appears to mean 'standard reply payload'.

**Workaround**: hci_verifier.protocol.SERVER_FLAG_REPLY / SERVER_FLAG_BROADCAST / SERVER_FLAG_HEARTBEAT / SERVER_FLAG_EMPTY_REPLY constants.

### 18. [NOTE] §3.1.1 Length field semantics

**Claim**: 'The length field, 16 bit word, holds the number of bytes of the complete transport packet.'

**Observed**: This statement IS correct in normal operation (size = total packet bytes including start/end). However the §3.1.3 ping example contradicts it (see next entry).

### 19. [NOTE] §3.1.4 Client Session Closure

**Claim**: 'When ending the HCI session... the HCI client should forcefully close the socket connection, as opposed to gracefully flushing the socket before closure.'

**Observed**: Confirmed required. Implemented via SO_LINGER {l_onoff=1, l_linger=0} which causes TCP RST on close().

**Workaround**: HciTransport.close(force_rst=True) (default)

### 20. [NOTE] §4 Alias Add — first byte after count

**Claim**: Manual structure unclear about a leading 0 byte per entity.

**Observed**: Training code (alias.py) prepends a signed 2-byte zero (struct format 'h') before each entity record on Add only — not on Delete. The training code comment explicitly says 'Need to ask Jim what this 0 value is for - manual not clear'.

**Workaround**: hci_verifier.verified_messages.build_alias()

### 21. [NOTE] §4 Crosspoint Action — bit layout (cross-ref to manual p.40)

**Claim**: §3 + §4 describe Crosspoint Action as Add Enable / Delete Enable / Add Inhibit / Delete Inhibit, with priority levels.

**Observed**: The training code (xpt_action.py) uses a packed 4-word body per action, with fixed bit-masks 0x2400 (word 0) and 0x03FA (word 3), direction in bit 0 of word 0, enable_inverse in bit 11 of word 3, xpt_priority in bits 13-15 of word 3, source/destination split as MSB+LSB across words 0 and 1. action_type=1 prefixes each block.

**Workaround**: hci_verifier.verified_messages.build_xpt_action()

### 22. [NOTE] §4 KEY_STATUS_AUTO_UPDATES subscription persists across SET_PROXY_DISPLAY

**Claim**: Earlier hypothesis (after Phase 5): SET_PROXY_DISPLAY may have broken the key-press subscription, since 0 msg 321 events were observed during a 15-second drain immediately after subscribing and writing 2 proxy displays.

**Observed**: Phase 11 (2026-05-08): subscribe → 2 SET_PROXY_DISPLAY (replicating Phase 5 exactly) → LED marker → 30 second drain → 23 msg 321 events received when operator pressed keys. Subscription persists. Phase 5's 0 events was operational: no LED marker was set, so the operator had no visual cue to press a specific key. Always set a SET_PROXY_INDICATION marker when expecting interactive press operations.

### 23. [NOTE] §4 Reply Key Pressed Status (msg 321) entries reflect both press AND release

**Claim**: msg 321 documented as 'key pressed status'.

**Observed**: Phase 11 captured 23 events from a few physical key presses. The state byte (offset 5 of each 7-byte entry) took values 0x01 (likely press) and 0x07 (likely release or hold-state), and the latch byte (offset 6) varied across 0x00, 0x12, 0x24. Multiple keys (K16=0x10, K17=0x11, K18=0x12) were captured even though only K16 had the LED marker — subscription captures every key pressed on the subscribed port range.

### 24. [NOTE] §4 msg 151 (0x97) — fires on BOTH XPT add and delete (not delete-only)

**Claim**: Earlier errata draft tentatively said msg 151 appeared after XPT delete only.

**Observed**: Phase 10 confirms msg 151 fires once each on XPT_ACTION add AND delete (paired with msg 16 ack and msg 14 crosspoint status). 14-byte payload structure:
  count(H=3) + 3 entries of 4 bytes each.
Observed entries for src=1 -> dst=0 (V12RD_2 -> V12RD):
  add:    [80 01 00 CC] [80 00 00 CC] [00 01 00 CC]
  delete: [80 01 00 CC] [80 00 00 CC] [40 01 00 CC]
First byte of last entry differs: 0x00 = add, 0x40 = delete. Likely a XPT-state-diff or affected-endpoints notification.

### 25. [NOTE] §4 msg 344 (0x158) — Proxy Display State Changed (broadcast)

**Claim**: Manual does not document this message id.

**Observed**: Phase 10 confirms msg 344 fires after SET_PROXY_DISPLAY (msg 316) only — NOT after SET_PROXY_INDICATION (msg 312) or any other operation tested. flags byte = 0x10 (U bit set per §4.2 = 'status change message'). Payload echoes the new display text in UTF-16-BE. Most likely an unsolicited broadcast to all listening hosts that a proxy display field was modified.

### 26. [NOTE] §4 msg 361 (0x169) — undocumented, observed during Map download

**Claim**: Manual does not document this message id.

**Observed**: Phase 15: msg 361 fired exactly once during a Map download event, ~5s after the 'Map saved' broadcast log and before 'Map changed' log. Header flags=0x10 (U bit set = status change per §4.2). Payload = 4 bytes '08 00 00 00'. Likely a generic 'configuration state changed' notification.

### 27. [NOTE] §4 msg 8 (REPLY_CCF_FILE) — content and firing pattern

**Claim**: Manual does not document this message id.

**Observed**: Body (after 12-byte header) contains ASCII strings: 'New Configuration ' (config file label) followed by 'H_Median            ' (matrix name). Firing is NOT deterministically tied to a specific HCI command; observed to fire shortly after reconnect when prior session modified configuration (proxy display etc.). Phase 10 first run (fresh session, all triggers attempted): 0 firings. Phase 10 second run (reconnect, baseline drain): 2 firings within 1.5s of connect. Likely a CCF/config-version sync notification.

**Workaround**: Treat as informational; classify under MsgId.is_unsolicited_noise() if you do not need it.

### 28. [NOTE] §4 server flag 0x00 — semantics of empty flag on newer reply family

**Claim**: §4.2 says CSU sets N=1 'always' (described as N flag set in every server-to-host message).

**Observed**: Replies in the newer (msg id 300+) custom-key/proxy family consistently use flag=0x00 — N bit NOT set. Observed on msg 313 (SET_PROXY_INDICATION reply), msg 317 (SET_PROXY_DISPLAY reply), msg 319 (KEY_STATUS_AUTO_UPDATES reply). The manual claim 'N=1 always' is wrong for these messages.

**Workaround**: Do not rely on flag bit pattern to detect server replies; use msg_id + magic.

### 29. [NOTE] §4.10 / §4.13 — msg 17 is multiplexed by action_type field

**Claim**: §4.10 (Conference Action) and the Crosspoint Action both claim msg ID 17 (0x0011) without explicit cross-reference.

**Observed**: msg 17 carries an action_type discriminator at offset 0 of the Action Data block:
  action_type=0x0001 -> Crosspoint Action (XPT)
  action_type=0x0020 -> Conference Action
Other action_type values likely exist (GPO, etc.) but are not yet enumerated in our manual extract. Each subtype has its own 4-word body layout (different bit fields).

**Workaround**: Use ACTION_TYPE_CROSSPOINT (0x0001) and ACTION_TYPE_CONFERENCE (0x0020) constants in verified_messages.

### 30. [NOTE] §4.10 Conference Action — verified bit layout and 0-based addressing

**Claim**: §4.10 word 0 prose: 'bits 1,2: port number bits 8 & 9; bit 3: 0=listen, 1=talk; bit 10: 1; bits 11,12: conference number bits 8 & 9'. Word 1: 'bits 0-7: port number bits 0-7; bits 8-13: conference number, bits 0-7' (the 8-13 range is a manual typo; example proves it is 8-15).

**Observed**: Phase 13 verified (Median 2026-05-08): port=1, conf=0, add+talker → word0=0x0409, word1=0x0001. Matrix accepted and Reply Conference Status (msg 20) immediately reflected the new membership. Delete also works (direction bit 0 → word0=0x0408). 0-based addressing confirmed: PL001 (EHX UI #1) is wire conference 0; the wire 'port' field uses the same 0-based convention as XPT_ACTION.

**Workaround**: hci_verifier.verified_messages.build_conference_action().

### 31. [NOTE] §4.12 Reply Conference Status — minimum 4-byte payload for empty conference

**Claim**: §4.12: 'Port Count contains the number of Port Data items plus the Conference Data item.'

**Observed**: An empty conference (no members) returns port_count=1 and ONLY the Conference Data 16-bit word (no Port Data). Total payload = 4 bytes: count(H) + conf_data(H). Verified for both wire conf 0 and conf 1 (both empty in test setup).

### 32. [NOTE] §4.151-4.154 Role State — change events are NOT broadcast unsolicited

**Claim**: §4.152 'This message can be requested or sent unsolicited on a state transition.'

**Observed**: Phase 15 capture: 90s passive drain during EHX-driven ROLE SESSION START + ROLE SESSION END (visible in EHX log at 11:39:44 and 11:40:23). Zero msg 389 packets received unsolicited from the matrix during the session start/end transitions. Only obtained role state by explicit msg 388 polls before and after.

**Workaround**: Poll msg 388 to detect role state changes; do not rely on unsolicited msg 389.

### 33. [NOTE] §4.152 Reply Role State — configured_ep / physical_ep are 0 when role is Free

**Claim**: §4.152 implies Configured Endpoint type stores 'Panel type associated with the key configuration'. Suggests it should reflect the EHX UI configuration (e.g. 'V-Series 12 Lever').

**Observed**: On real Median, when a role is Free (no panel allocated), BOTH configured_ep and physical_ep return 0, even when EHX shows the role configured with 'Virtual Client | V-Series' or 'V-Series' (panel hardware code 0x8010 V-Series 1U Lever). Phase 12 captured: role 600 / 601 (wire) both with cfg=0, phys=0, status=Free. Likely these fields are populated only when status != Free (i.e., a real client logs in).

**Workaround**: Do not use Reply Role State to determine configured panel type for unallocated roles; use msg 184 Reply Port Info or read EHX configuration directly.

### 34. [NOTE] §4.46 Reply Port Info — multi-packet reply

**Claim**: §4.46 special notes mention 'Many messages may be required... in that case the flags will be used as in section 4.2'.

**Observed**: Confirmed: msg 184 commonly spans multiple packets. First packet has flags bit 4 (E=more) set (e.g. 0x11). Subsequent continuation packets have E=0 (e.g. 0x01) and the last has S=0 + E=0 (e.g. 0x00 in observed traffic). Concrete observed sequence for slot=2: 8 packets total, only the FIRST contains populated port records (V12RD wire 0 + VI-PNLB-12L wire 1). Continuation packets contain zero-filled port records (slot capacity is 16 but only 2 ports configured).

**Workaround**: When parsing msg 184, drain all packets until flags' E bit (0x10) is clear, then concatenate-or-scan all payloads.

### 35. [NOTE] §4.46 Reply Port Info — port label vs physical panel decoupling

**Claim**: Port label (Talk & Listen Label) and Panel Type are listed as separate fields without commentary on their relationship.

**Observed**: Port label is the EHX-configured port name and remains unchanged when the physical panel is swapped at the same port. Panel Type reflects the LIVE physical hardware. Example (2026-05-08): port wire 1 had label='V12RD_2' (unchanged from EHX config) but panel_type changed from 0x8016 (yesterday's Rotary panel) to 0x8010 (today's Lever panel). To detect physical-panel changes, monitor panel_type, not the label.

### 36. [NOTE] §4.46 panel_operational_status bit layout

**Claim**: Manual prose says 'Online (Bit 0): 0=offline, 1=online; Usage (Bit 1); Port Type (Bits 2-7)'.

**Observed**: Real-matrix bytes do not match this layout. Observed value 0xCE for connected V-Series panels would imply (per manual) online=0 (offline) and port_type=0x33=51 which is not in the Port Type enum (max 31). Treating bit 7 as online and bits 0-5 as port_type yields online=1 + port_type=0x0E=14 = 'Panel' which matches reality. Likely the manual numbers bits MSB-first while implementation is LSB-first, or the bit positions are simply documented in reverse order.

**Workaround**: parse_port_info_reply() uses bit 7 = online and bits 0-5 = port_type. Verify on a known-online panel before relying on the online flag.


