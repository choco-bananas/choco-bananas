# INDEX (MSG# / topic 検索表)

タスクで参照すべきファイルだけを Read するために、まずこのテーブルで該当箇所を引く。

## MSG# 一覧 (実機観測あり)

| MSG | 方向 | 名前 | ファイル | 重要度 / errata |
|---|---|---|---|---|
| 1   | S→C | Broadcast System Message | `messages/MSG-001-broadcast-system.md` | major: ヘッダ非標準 (MAGIC なし) |
| 5   | C→S | Request Panel Status | `messages/MSG-005-030-panel-status.md` | note: 文書化されていないが discovery に必須 |
| 8   | S→C | Reply CCF File | `messages/MSG-008-reply-ccf-file.md` | note: Map download 後の config sync |
| 14  | S→C | Crosspoint Status | (参考のみ — MSG-150-151 と MSG-039-040 を参照) | note |
| 16  | S→C | Reply Action Status | (参考のみ — MSG-017 を参照) | minor: host_ip は u32、stride 10 |
| 17  | C→S | Crosspoint / Conference Action | `messages/MSG-017-action.md` | **major**: action_type 多重化、bit-packed body |
| 20  | S→C | Reply Conference Status | (MSG-017 内に統合記載) | note: 空 conference は 4 byte payload |
| 30  | S→C | Reply Panel Status | `messages/MSG-005-030-panel-status.md` | note: panel_type 粗い (PANEL_GENERIC=1)、判別は MSG 184 |
| 38  | C→S | Set Crosspoint Level | `messages/MSG-038-set-xpt-level.md` | **major**: 22-byte frame、MSG 40 unsolicited broadcast |
| 39  | C→S | Request Crosspoint Level | `messages/MSG-039-040-xpt-level.md` | note |
| 40  | S→C | Reply Crosspoint Level | `messages/MSG-039-040-xpt-level.md` | note: MSG 38 後の unsolicited あり |
| 132 | C→S | Delete Alias | (動作確認のみ、固有 errata 無し) | |
| 150 | C→S | Request Xpt and Level | `messages/MSG-150-151-xpt-and-level.md` | note: T/L expansion 必要 |
| 151 | S→C | Reply Xpt and Level | `messages/MSG-150-151-xpt-and-level.md` | note: M/T/L bit layout、add/delete 両方で fire |
| 183 | C→S | Request Port Info | `messages/MSG-183-184-port-info.md` | note: slot 2..20 を順次照会 |
| 184 | S→C | Reply Port Info | `messages/MSG-183-184-port-info.md` | **major**: multi-packet、panel_type は 16-bit (0x80xx)、stride 動的 |
| 237 | C→S | Request Key Assign Status | `messages/MSG-237-238-key-assign.md` | note: 旧記述。詳細は実装で要確認 |
| 238 | S→C | Reply Key Assign Status | `messages/MSG-237-238-key-assign.md` | note |
| 244 | C→S | Unicode Alias Add | (動作確認のみ) | |
| 312 | C→S | Set Proxy Indication | `messages/MSG-312-313-set-proxy-led.md` | **major**: 24-byte frame (旧 26 byte 末尾 garbage バグ)、"pad" 実態は mic byte |
| 313 | S→C | Reply Set Proxy Indication | `messages/MSG-312-313-set-proxy-led.md` | note: silent rejection あり、count=0 で reject |
| 314 | C→S | Request Get Proxy Display | `messages/MSG-314-315-proxy-display-get.md` | note |
| 315 | S→C | Reply Get Proxy Display | `messages/MSG-314-315-proxy-display-get.md` | note: 3RDPARTY assign 一覧 |
| 316 | C→S | Set Proxy Display | `messages/MSG-316-317-proxy-display-set.md` | major: text field 20 byte (旧 40 byte バグ) |
| 317 | S→C | Reply Set Proxy Display | `messages/MSG-316-317-proxy-display-set.md` | note |
| 318 | C→S | Request Key Auto Updates | `messages/MSG-318-319-321-key-events.md` | **major**: 19-byte frame (旧 21 byte 末尾 garbage バグ) |
| 319 | S→C | Reply Key Auto Updates | `messages/MSG-318-319-321-key-events.md` | note |
| 321 | S→C | Reply Key State | `messages/MSG-318-319-321-key-events.md` | **major**: state byte は bitmap、詳細は `topics/state-byte-bitmap.md` |
| 344 | S→C | Proxy Display State Changed (broadcast) | `messages/MSG-344-proxy-display-broadcast.md` | note: MSG 316 後の unsolicited |
| 361 | S→C | Config Change Notification (unknown) | `messages/MSG-361-config-change.md` | note: Map download 後 1 度 fire |
| 363 | S→C | Heartbeat | `messages/MSG-363-heartbeat.md` | note: 1Hz 85-byte、drain 必須 |
| 388 | C→S | Request Role State | `messages/MSG-388-389-390-role.md` | note: poll only (unsolicited なし) |
| 389 | S→C | Reply Role State | `messages/MSG-388-389-390-role.md` | major: configured_ep は role 設定、physical は MSG 184 で別取得 |
| 390 | C→S | Role State Set | `messages/MSG-388-389-390-role.md` | major: Field Trial fw で status=0 (Free) 拒否される |
| 398 | C→S | Disconnect Session | (動作確認のみ) | major: Role 解放には使えない (Field Trial fw) |

## Topics (横断、MSG# によらない知見)

| Topic | ファイル | 使う場面 |
|---|---|---|
| **state byte bitmap (msg 321)** | `topics/state-byte-bitmap.md` | キーイベント解釈、Push/LongPush 判定、bit 3 erratum (2026-05-14) |
| V-Series panel 構造 | `topics/V-Series-panel-structure.md` | region/face/key# 計算、slot ↔ Talk/Listen/VolUp/VolDn |
| Frame format / FLAGS | `topics/frame-format-and-flags.md` | builder/parser 実装、broadcast 判定 |
| 接続・port 多重 | `topics/connection-and-ports.md` | 接続実装、52001→52002→52003 fallback |
| level↔dB 変換 | `topics/level-to-db.md` | MSG 38 / 39 / 40 / 150 / 151 共通 |
| Front panel controls (rgn=0) | `topics/front-panel-controls.md` | Mic On / Headset / Shift Page 等の検出 |
| Call Signal | `topics/call-signal.md` | V12PD VolUp+VolDn 同時押 / V12RD rotary 長押 |
| 既知の落とし穴 | `topics/known-pitfalls.md` | 開発開始時にまず一読推奨 |

## raw/ (原典、通常使わない)

| ファイル | 内容 |
|---|---|
| `raw/kb-337-errata-catalog.md` | v0.3.0 時点 errata 36 件 (出所: hci-verifier 検証 phases 1-15) |
| `raw/kb-341-errata-supplement.md` | 2026-05-12/13 補遺 (state bitmap、V12RD 物理構造、front controls、MSG 17、port 多重 etc.) |
| `raw/kb-344-bit3-erratum.md` | 2026-05-14 bit 3 仮説撤回 + 新発見 (long-push 閾値、VolUp/VolDn press-only、stale 0x07 復帰) |
| `raw/hardware-md-snapshot.md` | MTC HCI セッションの hardware.md スナップショット (機材構成 + 全 errata 統合) |

## 検証機材

| HCI port | 物理 Panel | configsoft Label | panel_type code |
|---|---|---|---|
| 0  | V12RD (Rotary) | V12RD | 0x8016 |
| 1  | V12RD_2 (Rotary 物理は VI-PNL-12R / VI-PNLB-12L 切替) | V12RD_2 | 0x8016 (Rotary) / 0x8010 (Lever) |
| 80 | E-IPA-HX 経由 V12PD (Push) | E-IPA_IVC / V12IP1 | 0x8011 (Push) / 0x8016 (Rotary 表示時もあり) |

CSU: Median 192.168.0.150、HCI port 52001/52002/52003 多重 listener。

## 参照優先順位 (タスク開始時のフロー)

1. ユーザー指示の MSG# を上の表で引く → ファイル名 1 つ取得
2. そのファイルを Read
3. ファイル先頭の「依存 topic」リンクが示す `topics/*.md` を必要分だけ Read
4. 矛盾や疑問があれば `raw/` を参照
5. それでも不明 → ユーザー照会
