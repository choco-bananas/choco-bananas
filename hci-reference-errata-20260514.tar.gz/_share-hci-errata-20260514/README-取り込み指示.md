# HCI Reference Errata 引継ぎパッケージ (2026-05-14、MTC HCI セッションから)

## 受領 agent への指示 (まずこれだけ読む)

**全ファイルを pre-load しないこと**。本パッケージは「必要な時に必要箇所を参照」する knowledge base として使う前提で構造化されている。検索順序は以下:

1. **タスク開始時に読むのはこの README と `INDEX.md` のみ** (合計 ~200 行)
2. ユーザーから具体的タスク (例: 「MSG 38 で xpt 書込みを実装したい」) が出たら、`INDEX.md` の MSG 表から対象ファイル名を引いて **そのファイルだけ Read** する
3. cross-cutting な疑問 (例: 「state byte の bit 構造」「Region 番号付け規則」) は `topics/*.md` に分離してある — INDEX.md の "Topics" 表を参照
4. 過去の生資料スナップショット (errata カタログ / 補遺 / hardware ドキュメント) は `raw/` に**保存のみ**配置。基本は `messages/` と `topics/` の整形済みファイルを使い、`raw/` は 検証経緯や原典確認時のみ参照
5. **絶対にやらないこと**: README、INDEX、messages/*.md、topics/*.md、raw/*.md を全部一気に Read で読み込む (token 浪費の原因)

## このパッケージの目的

Clear-Com Eclipse HX matrix の HCI 2.0 API を扱う際の **実機検証済 errata と挙動メモ** を MSG# ごと + 横断 topic ごとに整理。同じ matrix を相手にする並列セッションが、誤った仕様前提で試行錯誤するのを防ぐ。

## ワークスペース配置の推奨

ホスト agent の作業フォルダ (例: `<project-root>/`) に展開し、以下のいずれかに置く:

```
<workspace_root>/
├── notes/hci-reference/          ← 推奨。読み取り専用 reference として
│   ├── README-取り込み指示.md
│   ├── INDEX.md
│   ├── messages/
│   ├── topics/
│   └── raw/
```

もしくはユーザーが指定する場所。

## 全ファイル一覧 (詳細は INDEX.md)

```
README-取り込み指示.md       (本ファイル)
INDEX.md                      (MSG#/topic 検索表)
messages/                     (MSG# 別)
  MSG-001-broadcast-system.md
  MSG-005-030-panel-status.md
  MSG-008-reply-ccf-file.md
  MSG-017-action.md           (XPT + Conference 共通 ID)
  MSG-038-set-xpt-level.md
  MSG-039-040-xpt-level.md
  MSG-150-151-xpt-and-level.md
  MSG-183-184-port-info.md
  MSG-237-238-key-assign.md
  MSG-312-313-set-proxy-led.md
  MSG-314-315-proxy-display-get.md
  MSG-316-317-proxy-display-set.md
  MSG-318-319-321-key-events.md  (subscribe + event)
  MSG-344-proxy-display-broadcast.md
  MSG-361-config-change.md
  MSG-363-heartbeat.md
  MSG-388-389-390-role.md
topics/                        (横断)
  state-byte-bitmap.md         (msg 321 state byte = bitmap、超重要)
  V-Series-panel-structure.md  (region / face / key# / slot mapping)
  frame-format-and-flags.md    (フレーム構造、FLAGS bit、MAGIC、SCHEMA)
  connection-and-ports.md      (52001-52003 多重 listener)
  level-to-db.md               (level↔dB 変換式)
  front-panel-controls.md      (rgn=0 K# mapping)
  call-signal.md               (V12PD VolUp+VolDn / V12RD rotary 長押)
  known-pitfalls.md            (16 の落とし穴)
raw/                           (原典コピー、検証経緯確認用、通常読まない)
  kb-337-errata-catalog.md     (v0.3.0 時点 errata 36 件)
  kb-341-errata-supplement.md  (2026-05-12/13/14 補遺 A-J)
  kb-344-bit3-erratum.md       (2026-05-14 bit 3 撤回 + 新発見)
  hardware-md-snapshot.md      (発信元セッションの hardware.md スナップショット)
```

> 注: `raw/` のファイル名先頭の `kb-NNN-` は出所識別子 (発信元セッションでの管理 ID)。**受領側で kb システムを利用する必要はない**。普通の markdown ファイルとして扱える。文中に kb#NNN への相互参照が現れるが、その実体はすべて本パッケージ内の `raw/kb-NNN-*.md` に同梱済。

## バージョンと出所

- スナップショット日: **2026-05-14**
- 出所: Clear-Com Eclipse HX matrix の HCI API 実装プロジェクト (会社 PC 環境)
- 検証機材: Median CSU 192.168.0.150、E-IPA-HX、V12RD/VI-PNL-12R/VI-PNLB-12L/V12PD/V12IP1
- 旧記述の撤回箇所あり (`raw/kb-344-bit3-erratum.md` = bit 3 仮説撤回) — 必ず 2026-05-14 確定版を参照

### 機密区分

- 本パッケージは **MTC 業務機密** (検証機材構成 IP / panel 型番 / 検証手順 等を含む)
- **外部送信禁止**。受領側でも社外への共有・転載をしないこと
- 自社業務上、ローカルワークスペースに保管・参照するのは可

## 不明点・矛盾を見つけた場合

- まず `raw/` の原典スナップショットを確認
- それでも判断つかなければ **ユーザーに照会**
- 受領側で実機検証して新発見があった場合は、自セッションのローカル notes に記録し **本パッケージにはマージしない** (発信元のバージョン管理を尊重)。発信元と統合更新したい場合はユーザー経由で連絡
