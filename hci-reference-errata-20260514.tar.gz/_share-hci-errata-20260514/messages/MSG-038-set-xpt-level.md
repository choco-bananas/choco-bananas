# MSG 38 — Set Crosspoint Level (C→S)

依存 topic: `topics/level-to-db.md` (level↔dB)、`messages/MSG-039-040-xpt-level.md` (Reply unsolicited)。

## 用途

Crosspoint の talk level を直接 set。**現状の主力 write 系**。

## フレーム

22 byte total、payload = `count(u16=1) + (dest u16, src u16, level u8)`:

```
[START][SIZE=22][MSG=38][FLAGS=0x08][MAGIC=0xABBACEDE][SCHEMA=0x01]
[count=1 u16][dst u16][src u16][level u8]
[END]
```

## 実機検証済挙動 (kb#341 §G、2026-05-12)

| 送信 | 受信 (MSG 40 unsolicited) | 解釈 |
|---|---|---|
| dst=1 src=1 level=0xCC | src=1 dst=1 level=204 | **+0.00 dB** ✓ (LEVEL_0DB) |
| dst=1 src=1 level=0xD5 | src=1 dst=1 level=213 | **+3.19 dB** ✓ (spec 式 (213-204)*0.355=3.195) |
| dst=1 src=1 level=0x00 | src=1 dst=1 level=0 | **MUTE** ✓ |

## 重要挙動

1. **MSG 38 送信後、matrix が MSG 40 を unsolicited broadcast**。client は polling 不要、subscribe 不要、`_on_pkt` で受け取るだけ
2. **level=0 は soft MUTE** — entry 自体は残る、MSG 40 reply に level=0 として現れる
3. spec §4.18 の dB 換算式 `(level - 204) × 0.355` と完全一致

## MSG 17 delete との関係 (kb#341 §F)

本 matrix fw では **MSG 17 direction=0 ≅ MSG 38 level=0**。xpt 削除は MSG 38 で十分。詳細は `messages/MSG-017-action.md`。
