# MSG 361 — Config Change Notification (S→C, unknown)

## ⚠ マニュアル未掲載 (kb#337 #26)

msg id 0x169。

## 観測

Phase 15 (2026-05-08): Map download event 中に **正確に 1 回 fire**。"Map saved" broadcast log の ~5 秒後、"Map changed" log の前。

## フレーム

- header flags = `0x10` (U bit set = status change per §4.2)
- payload = 4 bytes `08 00 00 00`

## semantics (推測)

汎用的な "configuration state changed" 通知と推定。詳細は未解明 (state.md Open questions の "msg 361 payload 意味" に残存)。

## 用法

informational。`MsgId.is_unsolicited_noise()` 相当で skip 可。
