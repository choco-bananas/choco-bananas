# MSG 5 / MSG 30 — Request / Reply Panel Status

依存 topic: なし (単独で使える)。Panel 種別を厳密判定したい場合は `messages/MSG-183-184-port-info.md`。

## 方向

- MSG 5 (C→S): Request Panel Status (引数なし or 最小)
- MSG 30 (S→C): Reply Panel Status (port list with type/state)

## 用途

Discovery。HCI に配信される全 panel を一覧で取得。

## 重要 errata

### kb#337 #11 — panel_type field は判別に使えない

MSG 30 の `panel_type` 列は **8 個の粗い enum** (PANEL_GENERIC=1, antenna types 等)。

- VI-PNL-12R (Rotary) と VI-PNLB-12L (Lever) は **両方 PANEL_GENERIC=1** として返る
- 物理機種の判別は **MSG 184 の 16-bit panel_type** (0x8000-0x8204) を使う

実機マップ (2026-05-08):
- port 0 V12RD → MSG 184 で 0x8016 (V-Series 1U Rotary)
- port 1 VI-PNLB-12L → MSG 184 で 0x8010 (V-Series 1U Lever)
- port 80 VI-PNL-12R → MSG 184 で 0x8016 (Rotary)

命名規則: `12L` = Lever (0x8010)、`12R` = Rotary (0x8016)、`B` = Black variant (同コード)。

### kb#337 #14 — MSG 5/30 はマニュアル §4 catalogue に未掲載

正式仕様にないが discovery には必須。`build_request_panel_status` + `parse_panel_status` helpers を実装する。

## 実用フロー

```python
panels = build_request_panel_status() → MSG 5
reply = wait_for_msg(30)
for entry in reply.entries:
    # entry: port_lo, type, state, port_hi
    request_port_info(slot=entry_slot) → MSG 183 で詳細取得
```
