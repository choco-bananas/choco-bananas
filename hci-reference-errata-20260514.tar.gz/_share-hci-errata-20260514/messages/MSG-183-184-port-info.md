# MSG 183 / MSG 184 — Request / Reply Port Info

依存 topic: `topics/V-Series-panel-structure.md` (panel_type 解釈)、`topics/frame-format-and-flags.md` (multi-packet)。

## 方向

- MSG 183 (C→S): Request、引数は slot 番号 (HCI slot 2..20 を順次照会)
- MSG 184 (S→C): Reply、slot 内 16 port 分の詳細

## Slot ↔ Port mapping

```
HCI slot N  ⇔  configsoft slot (N-1)
HCI slot 2  →  HCI ports 0..15    (= configsoft slot 1, ports 1..16)
HCI slot 7  →  HCI ports 80..95   (= configsoft slot 6, ports 81..96)

port = (slot - 2) * 16 + offset    # HCI slot 1-based, port 0-based
探索範囲: slot 2..20
```

## ⚠ Multi-packet reply (kb#337 #34)

MSG 184 は **しばしば複数 packet にまたがる**:

- 最初の packet: flags bit 4 (E=more) set (例: 0x11)
- 続行 packet: E=1 (例: 0x01)
- 最終 packet: S=0 + E=0 (例: 0x00)

実例 (slot=2): 8 packets、**最初の 1 つだけが populated port records** を含む。残り 7 つは slot capacity 16 で未使用 port を zero-fill。

実装: flags E bit (0x10) が clear になるまで drain → 全 payload を concatenate or scan。

## ⚠ per-port stride (本機実測)

`stride = 73 + 12 * n_exp` — 本機 n_exp=21 → stride=325。**動的計算すること**、他環境で異なる可能性。

## panel_type field (16-bit、kb#337 #11)

MSG 30 の coarse enum と別。0x8000-0x8204 で **物理ハードウェア機種** を表す:

| code | 機種 |
|---|---|
| 0x8010 | V-Series 1U Lever (VI-PNLB-12L) |
| 0x8011 | V-Series 1U Push (V12PD) |
| 0x8016 | V-Series 1U Rotary (V12RD / VI-PNL-12R / VI-PNLB-12R) |
| 0x80xx | (他、要 catalog 確認) |

命名規則: `12L` = Lever (0x8010)、`12R` = Rotary (0x8016)、`B` = Black variant (同コード)。

## port label vs panel_type 切り離し (kb#337 #35)

- **port label**: EHX 設定の port 名 (例 "V12RD_2")。物理 panel を swap しても変わらない
- **panel_type**: live な物理ハードウェア

例: port wire 1 で `label='V12RD_2'` 不変、`panel_type` は Rotary 接続時 0x8016 / Lever 接続時 0x8010。

→ 物理 panel 変更検知には **panel_type を監視**、label は使わない。

## ⚠ panel_operational_status bit layout (kb#337 #36)

マニュアル prose: "Online (Bit 0): 0=offline, 1=online; Usage (Bit 1); Port Type (Bits 2-7)"。

**実機バイトと一致しない**。観測値 `0xCE` は:

- マニュアル通り解釈 → online=0 (offline), port_type=0x33=51 (enum 範囲外、最大 31)
- **逆順 (bit 7 = online、bits 0-5 = port_type)** → online=1, port_type=0x0E=14 = 'Panel' ✓

実装は bit 7 = online, bits 0-5 = port_type で parse。

## Talk & Listen Label

UTF-16-BE で encode (LE ではない、kb#337 / pitfalls #6)。
