# MSG 39 / MSG 40 — Request / Reply Crosspoint Level

依存 topic: `topics/level-to-db.md`、`messages/MSG-150-151-xpt-and-level.md` (代替経路)、`messages/MSG-038-set-xpt-level.md` (set 経路と unsolicited reply)。

## 方向

- MSG 39 (C→S): Request、引数 = destination port (基準: dest 視点で接続中 src の一覧)
- MSG 40 (S→C): Reply、ペイロード = (src, level) tuple list (count + entries)

## 重要挙動

### unsolicited broadcast (kb#341 §G)

MSG 38 (Set XPT Level) を実行すると、**matrix から MSG 40 が unsolicited で送られてくる**:

- client は subscribe 操作不要
- `_on_pkt` で受け取り、latest state を track できる
- polling は通常不要 (初期 query で MSG 39 を 1 回叩いて initial snapshot を得る、以降は unsolicited で update)

### self-talk 返却

2026-05-12 早朝の記録: 「MSG 39/40 は self-talk を返さない」 → **訂正**。host-set self-xpt (src=dst) は MSG 40 で返る。前回観測時は xpt が存在しなかっただけ。

### MSG 150/151 との比較

| Msg pair | 基準 | 返り | self-talk |
|---|---|---|---|
| MSG 39 / 40 | destination port | (src, level) リスト | 返る |
| MSG 150 / 151 | source port | T/L flag 付き両方向 + self、+ level | 返る |

`HciClient.discover()` では MSG 150 を V-Series 各 source port に送って _xpt_levels dict に集約、以降の MSG 40 broadcast で incremental update。
