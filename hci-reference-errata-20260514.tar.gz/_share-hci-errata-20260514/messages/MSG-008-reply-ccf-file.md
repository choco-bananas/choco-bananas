# MSG 8 — Reply CCF File (S→C)

## 用途

Map download 後の **config version sync notification**。マニュアル §4 catalogue に未掲載 (kb#337 #27)。

## ペイロード

12 byte header の後、ASCII strings:

```
"New Configuration " (label)
"H_Median            " (matrix name、20 byte padded)
```

## firing pattern

- **EHX Map Download 時**: `msg 8` × 2 が連続 fire
- **TCP 再接続時**: 直前のセッションが config 変更したまま閉じていた場合、再接続後 1.5 秒以内に 2 firings
- 特定の HCI command に対する直接 reply ではない (broadcast 的)

## v0.4.0 候補課題 (kb#341 関連)

trigger の完全網羅は未確認。`msg 8 trigger 完全網羅` が state.md Open questions 候補。

## 推奨処理

informational として扱う。`MsgId.is_unsolicited_noise()` 相当で skip 可。
