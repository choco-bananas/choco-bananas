# MSG 316 / MSG 317 — Set Proxy Display / Reply

依存 topic: `messages/MSG-344-proxy-display-broadcast.md` (set 後の broadcast)。

## 方向

- MSG 316 (C→S): Set Proxy Display (テキスト書込み)
- MSG 317 (S→C): Reply

## ⚠ Major errata: text field 20 byte (旧 40 byte は誤り、kb#337 #2)

`build_set_proxy_display_state` の v0.1 → v0.2 で発生した regression:

- **正しい**: text field は **20 bytes** (= 10 UTF-16-BE 文字)
- **誤り**: 40 bytes alloc は v0.1 のバグ、v0.2 で再混入

`'40s' → '20s'` に修正。

## 後続 broadcast: MSG 344

MSG 316 set 後、matrix は **MSG 344 (Proxy Display State Changed)** を unsolicited broadcast (flags=0x10, U bit set)。
詳細: `messages/MSG-344-proxy-display-broadcast.md`

注: MSG 312 (Set Proxy Indication) では MSG 344 は fire しない (kb#337 #25)。

## Silent rejection

MSG 316 でも MSG 312 同様、誤った struct で送ると msg 317 が flag=0x00 count=0 で返る。reply 結果を判定する場合は count を見る (kb#337 #8)。

## reply flag

MSG 317 は flag=0x00 (N bit 立たない、kb#337 #28)。
