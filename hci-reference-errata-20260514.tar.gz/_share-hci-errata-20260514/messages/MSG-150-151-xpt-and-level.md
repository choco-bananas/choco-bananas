# MSG 150 / MSG 151 — Request / Reply Xpt and Level

依存 topic: `topics/level-to-db.md`、`messages/MSG-039-040-xpt-level.md` (代替経路)。

## 方向

- MSG 150 (C→S): Request、source port を基準に問い合わせ
- MSG 151 (S→C): Reply、(monitor + relations + level) のリスト。**T/L flag 付き**で両方向を 1 message で返す

## ペイロード構造 (kb#341 §G、実機検証済)

```
u16 count
repeat count times:
  u16 flags_port:  bit15=M (Monitored, header)
                   bit14=T (Talk, monitor→port)
                   bit13=L (Listen, port→monitor)
                   bits9..0=Port (10-bit)
  u16 level
```

- **M=1 entry** が monitor port 宣言、後続の M=0 entries が relation
- T+L 同時 set は self-talk または bidirectional (parser でデドゥープ)
- self-talk: monitor port と関係先 port が同じ + T+L 両 bit set

## 実機例 (V12RD_2 自己 talk 中)

```
payload: 00 02 80 01 00 00 60 01 00 CC
         count=2, entry1: M=1 port=1, entry2: T+L port=1 level=0xCC
解読:    monitor=1, self xpt at +0.00 dB
```

## 重要挙動

- xpt add/delete (MSG 17 or MSG 38) 後の **unsolicited 配信あり** (hci-verifier で確認)
- kb#337 #24: msg 151 は add でも delete でも fire (delete-only ではない)。14-byte payload で count(H=3) + 3 entries
- `HciClient.discover()` は MSG 150 を V-Series 各 source port に対して自動送信し、`_xpt_levels` dict にキャッシュ
- MSG 40 auto-broadcast も同じ dict を更新
