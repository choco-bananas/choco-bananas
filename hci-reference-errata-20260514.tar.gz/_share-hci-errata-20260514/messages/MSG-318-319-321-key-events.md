# MSG 318 / 319 / 321 — Key Auto Updates (Subscribe + Reply + Events)

依存 topic: **`topics/state-byte-bitmap.md` (msg 321 state byte = bitmap、超重要)**、`topics/call-signal.md`、`topics/V-Series-panel-structure.md`。

## 方向

- MSG 318 (C→S): Request Key Auto Updates (subscribe / unsubscribe)
- MSG 319 (S→C): Reply Key Auto Updates (ack)
- MSG 321 (S→C): Reply Key State (unsolicited、subscribe 中のみ)

## ⚠ Major errata: MSG 318 frame は 19 bytes (旧 21 byte 末尾 garbage バグ、kb#341 §I)

旧 `ehx-vol-ctrl` の `buildKeyAutoUpdates` は 21 bytes alloc + SIZE=21 だが実際の意味あるデータは 19 bytes、末尾 2 bytes は garbage。本セッション 2026-05-12 修正済。

### 正しいフレーム

```
[START][SIZE=19][MSG=318][FLAGS=0x08][MAGIC][SCHEMA=0x01]
payload: port_start(2) + port_end(2) + enabled(1) = 5 bytes
[END]
```

実装例 (TypeScript):
```typescript
const buf = Buffer.allocUnsafe(19);
let off = writeHeader(buf, 0, MSG.REQUEST_KEY_AUTO_UPDATES, 19);
buf.writeUInt16BE(portStart, off); off += 2;
buf.writeUInt16BE(portEnd,   off); off += 2;
buf.writeUInt8(enabled ? 1 : 0, off);
```

## MSG 319 (ack)

flag=0x00 で返る (kb#337 #28、N bit 立てない family)。

## MSG 321 (Reply Key State、unsolicited)

### Payload 構造 (kb#337 #1 — v0.2.0 regression あり、要注意)

```
u8 count
repeat count times:
  i16 panel  (signed)
  u8  region
  u8  page
  u8  key
  u8  state
```

- 各 event = 6 bytes (旧記述で 7 bytes / latch 含むとあったが、現代の parser は 6 byte stride で OK)
- v0.2.0 の `verified_messages.py` は v0.1 の buggy parser を残しており、schema(B)+count(B) と読んでしまう → 必ず修正版で

### state byte は bitmap (詳細は `topics/state-byte-bitmap.md`)

単純な make/break ではない。bit 0 (down) / bit 1 (Push) / bit 2 (LongPush) / bit 3 (再現不可、erratum) の組合せ。

典型遷移:
- 短押し: `0x01 → 0x02 → 0x00`
- 長押し: `0x01 → 0x07 → 0x04 → 0x00`
- VolUp/VolDn (Lever/Push): `0x01` のみ 1 event
- stale 0x07 復帰: `prev=0x07 → 0x03 → 0x04 → 0x00`

### subscription 永続性 (kb#337 #22)

MSG 318 subscribe 後、MSG 316 (Set Proxy Display) を送っても subscription は破壊されない。30 sec drain で 23 events 受信を確認 (Phase 11)。

Phase 5 で「0 events」と観測したのは LED marker 未設定で operator が押すキー判断できなかっただけ。**interactive 待ち時は SET_PROXY_INDICATION マーカーを必ず併用**。

### 全キーが届く

subscribe した port 範囲内の **全 key event が flood** する (kb#337 #23)。`port_start..port_end` 範囲を必要最小限に絞る、または client 側で filtering。

### Call Signal の解釈

詳細: `topics/call-signal.md`。

- V12PD: face の VolUp + VolDn ~50ms 以内同時押 → K=base+2 / K=base+3 が press のみ配信 (release 抜け)
- V12RD: rotary push 長押 → 標準 LongPush シーケンス

Client が Call Signal を区別する場合は **入力パターンを HCI イベント列から検出する** 必要あり。
