# MSG 363 — Heartbeat (S→C, unsolicited)

依存: `topics/frame-format-and-flags.md`

## ⚠ マニュアル完全未掲載 (kb#337 #16)

§3 + §4 全体で言及なし。

## 観測

TCP 接続確立後、**~1 秒間隔で 85-byte payload msg 363 が来続ける**。

```
header: MAGIC + schema=0x02
flags: 0x10 (U bit / heartbeat-style)
body 先頭: 01 4C 05 69 FC C? ?? ?? 08 00 FF FF
本体: 残り ほぼ zero
```

likely connection-level keepalive または system status。

## 必須処理

**drain して破棄しないと TCP 受信バッファが詰まる**。client は heartbeat msg を skip する仕組みを持つこと:

```python
# hci_verifier の例
MsgId.HEARTBEAT_363  # 定数
HciClient.recv_until_msg_id(skip_noise=True)  # 自動 skip
```

## 補足

接続が活きているかの判定にも使える (一定時間届かなくなったら TCP 異常を疑う、等)。
