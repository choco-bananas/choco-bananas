# MSG 1 — Broadcast System Message (S→C)

依存 topic: `topics/frame-format-and-flags.md` (非標準ヘッダ)

## 用途

Matrix が unsolicited で ASCII ログ行を broadcast する。TCP 接続時、Map download 時、role session 開始時など。

## 重要 errata (kb#337 #5)

**ヘッダが標準フレームと異なる** — MAGIC 0xABBACEDE が無い。

```
[START 0x5A0F][SIZE u16][MSG_ID=1 u16][FLAGS=0x30 u8]
[CATEGORY u32 (例: 0x0004023E or 0x0004017E)]
[u32 zero]
[ASCII payload, NUL-terminated]
[END 0x2E8D]
```

## 観測例

```
07/05/26 16:50:00.907,60|TCP host 192.168.0.10 port 49789 opened err 255
```

- `err 255` は **デフォルトコード** (実エラー意味なし、TCP 接続のたびに必ず出る)
- `ADM TCP:192.168.000.010 connected` 等の続報も来る
- Map download 時: `process_map=== 0`, `Map download was valid - saving Map 1`, `Clear Local Overrides...`, `Saving HXC to FLASH`, `NID HXC File Saved`, `Map changed, new configuration loaded`, `ROLE SESSION START/END`

## 注意

- **MAGIC が無いことを理由に reject しない** こと。parser は msg_id=1 を見て特別扱いする
- §3.1.1 (kb#337 #5) では「Same framing as other messages」と書かれているが嘘

## 接続後の最初のメッセージ (kb#337 #3)

**Reply CPU Status ではない**。最初は msg 1 broadcast がほぼ確実に来る (manual §2 の記述は誤り)。
