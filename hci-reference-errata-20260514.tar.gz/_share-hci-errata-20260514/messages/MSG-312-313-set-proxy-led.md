# MSG 312 / MSG 313 — Set Proxy Indication / Reply (LED 設定)

依存 topic: `topics/frame-format-and-flags.md` (24 byte 正規 frame)。

## 方向

- MSG 312 (C→S): Set Proxy Indication (LED state + mic flag)
- MSG 313 (S→C): Reply、silent rejection あり

## ⚠ Major errata: フレーム長 24 bytes (旧 26 byte は末尾 garbage バグ、kb#341 §J)

旧 `ehx-vol-ctrl` の `buildSetProxyLed` は 26 bytes alloc していたが、実際の正規 frame は **24 bytes**。本セッション 2026-05-12 修正済。

## ⚠ "pad" の正体は mic byte (kb#341 §J)

旧実装で `pad` と命名されていた byte は **mic flag** (0=disable, 1=enable)。意味のないパディングではない。

```typescript
buf.writeUInt8(mic, off);  // was "pad", actually mic byte
```

## ⚠ Silent rejection (kb#337 #8)

MSG 312 を **間違った struct で送ると、matrix は msg 313 を返すが flag=0x00 で count(h)=0** (entry なし)。

- 正しい frame: flag=0x00 + count=1+ で entry がエコーされる
- 区別する唯一の方法: **payload の count フィールド**。flag bits だけでは ack/nack 判定不可

実装ルール: MSG 312/316 等の proxy 系 request 後は、reply payload の count を必ず parse。`count=0` なら request が適用されていない。

### v0.1.0 の構造バグ (kb#337 #2)

`build_set_proxy_indication_state` で region が H (2 bytes) になっていた誤実装あり (正しくは B = 1 byte) + 末尾 padding 1 byte 余分。`v0.2.0` ではこの修正が漏れて regression していた。`'>HHHBBBBBB'` → `'>hhBBBBBB'` に。

## 観測

- msg 313 は flag=0x00 で返る (kb#337 #28 — 「N=1 always」は manual の誤り、msg id 300+ family は N bit 立てない)
- 後続: MSG 344 (Proxy Display State Changed) は **MSG 316 (Set Proxy Display) 後にのみ fire**、MSG 312 では fire しない (kb#337 #25)
