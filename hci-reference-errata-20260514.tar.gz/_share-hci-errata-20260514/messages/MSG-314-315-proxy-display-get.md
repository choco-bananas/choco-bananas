# MSG 314 / MSG 315 — Request / Reply Get Proxy Display

依存 topic: `topics/V-Series-panel-structure.md` (region/face/key# 理解)。

## 方向

- MSG 314 (C→S): Request Get Proxy Display (panel 指定 or panel=ALL)
- MSG 315 (S→C): Reply、各 panel の **3RDPARTY assignment 一覧** を返す

## 用途

各 panel/face の 3RDPARTY 表示 (label + 配置情報) を取得。Phase A1 で GUI mockup の主データ源として使用。

## 重要観測

### proxy entry 数の panel-type 依存

V-Series 1U panels の MSG 315 entry 数:

| Panel type | proxy entry 数 |
|---|---|
| V12LD (Lever) | 10 |
| V12RD (Rotary) | 12 |
| V12PD (Push) | **5** (slot 1 が物理不在のため半数) |

V12PD は BigButton で Talk + Listen を 1 ボタンで兼ねる UI 設計のため、slot 1 (Listen) は HCI に登録されない。

### page byte

MSG 315 の page byte: main page = 0、subsequent shift pages = 1, 2, 3, ... (Logic Ch4 序文より)。

### 3RDPARTY assignment は HCI 不可

EHX configsoft で **事前設定が必須** (pitfall #5)。HCI から assign の追加・変更はできない。

## 実装

`hci_client.py` の `request_proxy_display()` / `parse_msg315()`。
