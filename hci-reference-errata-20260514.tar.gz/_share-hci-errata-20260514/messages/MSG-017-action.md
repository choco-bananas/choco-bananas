# MSG 17 — Action (Crosspoint / Conference / その他、C→S)

依存 topic: `topics/frame-format-and-flags.md` (header)、`messages/MSG-038-set-xpt-level.md` (XPT 実効動作の代替手段)。

## 重要: action_type で多重化されている (kb#337 #29)

MSG 17 の **payload 先頭 u16 = action_type discriminator**。同じ msg_id で別動作:

| action_type | 用途 | 関連 msg |
|---|---|---|
| 0x0001 | Crosspoint Action (XPT add/delete enable/inhibit) | reply: msg 16 (action status) + msg 14 (xpt status) + msg 151 |
| 0x0020 | Conference Action (add/remove talker/listener) | reply: msg 20 (conference status) |
| その他 | GPO 等が存在する可能性 (要追加調査) | TBD |

## Crosspoint Action body 構造 (kb#337 #21、bit-packed)

Word 0..3 の **packed bit-mask**。マニュアル §3 + §4 の prose では決して読み取れない。HCITrainingDemo `xpt_action.py` 由来:

- 各 action は 4-word block
- Word 0 fixed mask `0x2400`、bit 0 = direction (0=delete, 1=add)
- Word 3 fixed mask `0x03FA`、bit 11 = enable_inverse、bits 13-15 = xpt_priority
- src/dst は MSB+LSB を Word 0 / Word 1 にまたいで配置

実装は `hci_verifier.verified_messages.build_xpt_action()` 参照。

## ⚠ 実機での効果 (kb#341 §F、本 matrix Field Trial fw)

**MSG 17 direction=0 (delete) で xpt を消そうとしても、entry は消えない**:

- 結果: xpt entry が **level=0 (MUTE) として MSG 40 reply に残存** (消失せず)
- 参考実装 `rotary_volume_ctrl.py` も MSG 17 を使わず **MSG 38 only** で運用
- 推測: 本 fw では "xpt delete" と "level=0 set" が等価実装
- 完全削除 path は別 MSG 経由かも (要追加調査)

### 実用ルール

**XPT 削除は `MSG 38 level=0` で行う**。MSG 17 は protocol 完備 (builder/parser 動作) するも実効果は MSG 38 と同じ。

**add 動作は未検証** (本 fw で MSG 17 add が xpt 作成できるかは未確認)。

## Conference Action body 構造 (kb#337 #30、検証済)

- マニュアル §4.10 prose: word 1 bits 8-13 を conference number と言うが **typo**、実際は bits 8-15
- 検証例 (Phase 13): port=1, conf=0, add+talker → word0=0x0409, word1=0x0001
- direction bit 0 → 0=delete, 1=add (XPT と同じ)
- **0-based addressing**: EHX UI の PL001 (#1) は wire conference 0
- delete は word0=0x0408 (bit 0 = 0)

## Reply Action Status (msg 16) layout (kb#337 #12 — manual 誤り)

- マニュアルは `host_ip` を 16-bit と書くが **実際は 32-bit IPv4**
- count(H) の後に 4 byte IPv4 (例: C0 A8 00 0A = 192.168.0.10)
- 各 action: `action_type(H) + 4 packed words` = 10 bytes / action (8 ではない)

## Reply Conference Status (msg 20) 最小 4-byte payload (kb#337 #31)

空 conference の場合: `count(H=1) + conf_data(H)` のみ、Port Data 部は省略される。
