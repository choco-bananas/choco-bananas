# MSG 237 / MSG 238 — Request / Reply Key Assign Status

## 方向

- MSG 237 (C→S): Request
- MSG 238 (S→C): Reply

## 現状

詳細な errata は未確定。kb#337 #14 で「manual §4 catalogue に未掲載」とされる observed message ID の 1 つとして言及されている。

実装で要確認 (parser/builder の精査 + 実機 reply 解析が必要)。

## v0.4.0 候補課題

state.md の Open questions に **action_type 列挙** / **face↔xpt mapping** (MSG 380/381 候補) が残っているが、237/238 は別系統のキー割当情報を返す可能性がある。実装時に対象 firmware で挙動確認のこと。
