# MSG 344 — Proxy Display State Changed (S→C, broadcast)

依存: `messages/MSG-316-317-proxy-display-set.md`

## 用途

EHX configsoft または **MSG 316 (Set Proxy Display)** で proxy display field が更新された時の unsolicited broadcast。

## ⚠ マニュアル未掲載 (kb#337 #25)

正式仕様にない msg id (0x158)。

## フレーム

- header flags = `0x10` (U bit set per §4.2 = "status change message")
- payload には新しい display text を UTF-16-BE で echo

## firing 条件

- **MSG 316 (Set Proxy Display) 直後**: fire する
- **MSG 312 (Set Proxy Indication / LED)**: fire **しない**
- それ以外の操作で fire するかは未確認

## 用法

全 listening host への "proxy display changed" 通知。client 側で proxy 表示を最新に保ちたい場合は subscribe 必要なく `_on_pkt` で受け取って apply。
